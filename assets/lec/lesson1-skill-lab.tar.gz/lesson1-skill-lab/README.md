# 实验一：修复坏 Skill —— 把「写→查→验」闭环固化成 Agent 的 SOP

> 课程第 1 节课配套实验 · 纯软件、零硬件依赖 · 课内约 12 分钟 + 课后完善
>
> 本讲义对应大纲「实验一：修复坏 Skill」。评分细则见文末「验收标准」。

---

## 1. 背景

Vibe coding 的正解不是「随缘生成」，而是**写得快 + 验得严**。要让 agent 稳定地「保证它能 work」，
就要把 **写代码 → 检查 → 验证** 的闭环写成一份 skill —— skill 就是给 agent 的实验操作规程（SOP）。

一份「保证 work」的 skill 必须做到四点：

1. **验证命令可执行**：能直接复制到终端跑，不是伪代码；
2. **成功标准机器可判**：exit code / 期望输出，不允许「看起来对了」；
3. **迭代有限**：失败后最多重试 N 轮；
4. **停止条件明确**：超限后停下来向人报告，而不是死循环烧 token。

本实验里，你的「病人」是一份**故意写坏的 skill**和一套**埋了 bug 的练习代码**
（模拟开发板上的 LED 控制器，board 用内存 dict 模拟，无需硬件）。
你要把 skill 修好，然后让 agent 在 skill 的驱动下自动修好代码 —— **闭环必须由 agent 走完，不是你自己动手修**。

## 2. 实验材料

```
lesson1-skill-lab/
├── README.md                        # 本讲义
├── Makefile                         # make setup / doctor / lint / test / check
├── requirements.txt                 # ruff + pytest
├── ruff.toml                        # 锁定 lint 规则集（保证各机器结果一致，勿删）
├── skills/
│   └── firmware-vibe-workflow/
│       └── SKILL.md                 # ★ 待修复的坏 skill（你的主要工作对象）
├── exercise/                        # ★ 埋了 bug 的练习代码（agent 的第二个工作对象）
│   ├── board_sim.py                 #   板子模拟器（内存 dict 模拟 GPIO/PWM，无 bug）
│   ├── led_controller.py            #   LED 控制器（埋了 bug，只许 agent 改这个文件）
│   ├── conftest.py                  #   pytest 路径配置（勿动）
│   └── tests/
│       └── test_led_controller.py   #   行为规格 = 机器可判标准（禁止修改）
└── teacher/                         # 教师专用（答案 + rubric），学生请勿打开
```

## 3. 任务总览

| # | 任务 | 产出 |
|---|---|---|
| 1 | 修复坏 skill `skills/firmware-vibe-workflow/SKILL.md` | 一份含五要素的合格 skill |
| 2 | 让 agent 按你的 skill 对 `exercise/` 走完 写→查→验 闭环 | `make check` 全绿（ruff 0 问题 + 11 passed） |
| 3 | 跨组交换测试：你的 skill 拿到 B 组环境能复现闭环 | B 组确认「能触发 + 全绿」 |

**两条纪律红线**（违反按 rubric 扣分，详见 teacher/rubric.md）：

- 测试即规格：**禁止修改/删除 `exercise/tests/` 里的任何用例**来「让它通过」；
- 闭环必须由 agent 在你的 skill 驱动下完成，**禁止绕过 agent 手工修 bug** 交作业。

## 4. 分步指引

### 第 0 步 · 环境准备（课前完成）

```bash
make setup     # 创建 .venv 并安装 ruff / pytest
make doctor    # 环境自检，全部 ✓ 才算就绪
```

### 第 1 步 · 确认初始状态（病人的病情）

```bash
make check
```

预期初始状态（这是 agent 闭环的**起点**，请截图/保存输出）：

- `make lint`：ruff 恰好报 **2 处**问题（都在 `led_controller.py`）；
- `make test`：pytest 恰好 **3 failed, 8 passed**。

> ⚠️ 看到失败不要自己动手修！你的任务是修 **skill**，让 agent 去修代码。
> 如果你改乱了练习代码想重来，找教师/助教要一份原始 `exercise/`。

### 第 2 步 · 诊断并修复坏 skill

打开 `skills/firmware-vibe-workflow/SKILL.md`，对照五条设计原则逐项修复：

| 原则 | 自问 |
|---|---|
| ① description 决定触发 | description 写清「**什么时候用**」了吗？有场景触发词（如「修改 exercise/ 下的 Python 代码」「修复 lint 或测试失败」）吗？ |
| ② 验证命令可执行 | 每条命令能直接复制到终端跑吗？本实验有现成的 `make lint` / `make test` / `make check` |
| ③ 成功标准机器可判 | 写了 exit code / 期望输出吗（如 `0 errors`、`11 passed`）？还是「看起来对了」？ |
| ④ 有限迭代 + 停止条件 | 失败最多重试几轮？超限后做什么（停止并向用户报告最后错误）？ |
| ⑤ 负面清单 | 堵住捷径了吗：不许改测试凑通过、不许未验证就宣布完成？ |

保持 SKILL.md 简短（渐进式披露）：正文只放流程和命令，背景知识不要堆进去。

### 第 3 步 · 安装 skill 并触发 agent

把修好的 skill 复制到你的 agent CLI 的 skill 目录（在实验目录下操作）：

```bash
# Claude Code
mkdir -p .claude/skills && cp -r skills/firmware-vibe-workflow .claude/skills/

# OpenCode
mkdir -p .opencode/skill && cp -r skills/firmware-vibe-workflow .opencode/skill/
```

> 每次改完 `skills/` 下的源文件，都要重新复制并**新开会话**再测。

给 agent 的指令示例：

```
使用 firmware-vibe-workflow skill，修复 exercise/ 里的全部问题，直到 make check 全绿。
```

**确认触发**：看 agent 是否引用了 skill 内容（复述流程步骤、执行你写的命令、遵守迭代上限）。
没触发就回去改 description —— 最常见的原因是缺场景触发词。

### 第 4 步 · 验收 + 跨组交换测试

1. 本组验收：`make check` 全绿（ruff 0 问题 + `11 passed`），且过程由 agent 完成；
2. 交换测试：把 `SKILL.md` **文本**发给 B 组；B 组在自己的环境（`exercise/` 必须是未修复的初始状态）
   按第 3 步同样操作。B 组确认「skill 能触发 + 闭环走完 + make check 全绿」才算 work。

## 5. 验收标准（rubric 摘要，总分 100）

| 维度 | 分值 | 看什么 |
|---|---|---|
| 闭环跑通 | 40 | skill 被触发（10）；agent 按 查→验→修→复验 顺序执行（15）；`make check` 全绿（15） |
| skill 质量 | 40 | 触发词 10 · 验证命令可执行 10 · 机器可判标准 10 · 停止条件 10 |
| 交换测试 | 20 | B 组环境能复现闭环（触发 + 全绿） |

自检清单：

- [ ] 初始状态确认过：ruff 2 处 + pytest 3 failed, 8 passed
- [ ] SKILL.md 含五要素（触发词 / 可执行命令 / 机器可判标准 / 迭代上限与停止条件 / 负面清单）
- [ ] agent 走完全程，`make check` 全绿（ruff 0 问题 + 11 passed）
- [ ] 未修改任何测试用例
- [ ] B 组用你的 SKILL.md 复现成功

## 6. 常见问题（FAQ）

**Q1：`make check` 报「✗ 先运行 make setup」？**
venv 不存在。先 `make setup`，再 `make doctor` 确认全 ✓。

**Q2：pytest 报 `ModuleNotFoundError: No module named 'board_sim'`？**
请用 `make test`（或 `make check`）在实验根目录跑；`exercise/conftest.py` 会处理导入路径。
如果你在 IDE 里单独跑测试文件，把工作目录设为实验根目录。

**Q3：agent 不触发我的 skill？**
三查：① skill 是否复制到 agent 的 skill 目录、目录层级对不对
（`.claude/skills/<skill 名>/SKILL.md`）；② 改完是否新开了会话；
③ description 是否含任务场景里的触发词（「修改 exercise/ 下 Python 代码时」这类），
太泛的 description（如「帮助编写高质量代码」）agent 永远不会加载。

**Q4：ruff 报的不是 2 处 / pytest 失败的不是 3 个？**
初始状态就是「2 处 + 3 failed, 8 passed」。数字不对说明练习代码被改动过 ——
找教师/助教要一份原始 `exercise/` 重来。

**Q5：agent 修完说「应该可以了」，但 `make check` 还是红？**
这正是本实验要治的病：skill 里没写「未跑 make check 通过不得声称完成」。
把这条加进负面清单，并要求 agent 贴出 `make check` 的实际输出。

**Q6：agent 想把测试改得宽松一点「让它通过」？**
立即制止。测试即规格，改测试 = 本实验不及格（见 rubric 违规项）。
在 skill 负面清单里明确禁止。

**Q7：网络 / API key 故障，agent 用不了？**
降级方案：自己扮演 agent，**严格按你写的 SKILL.md 逐字执行**（每一步照抄命令、
遵守迭代上限和停止条件）。skill 质量分照常评；课上再看教师录屏版演示。

**Q8：Windows 用户？**
Makefile 假定 macOS/Linux（venv 路径 `.venv/bin/`）。请用 WSL；
或手动执行等价命令：`.venv\Scripts\ruff check exercise/`、
`.venv\Scripts\python -m pytest exercise/tests/ -v`。

**Q9：目录里为什么有个 `ruff.toml`？能删吗？**
不能删。它把 lint 规则集锁定为 E4/E7/E9/F，保证任何机器上 `make lint`
的初始状态都恰好是 2 处问题（新版 ruff 的内置默认规则会随版本漂移，
你机器上的全局 ruff 配置也可能混进来）。如果初始 ruff 报错数不对，
先确认 `ruff.toml` 还在实验根目录。

## 7. 课后作业

完善本组 skill（补负面清单、调触发词、优化停止条件的措辞），
**下节课它将接上硬件**：验证步骤会从 `make check` 升级为 `flash + 硬件在环测试`。
