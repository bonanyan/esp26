"""板子模拟器：用内存 dict 模拟 ESP32 类开发板的 GPIO / PWM 状态。

纯软件实现，无任何硬件依赖：
- 每个引脚的状态存放在 dict 中，读写即时生效；
- 未初始化过的引脚读取时返回默认值（电平 0 / 占空比 0）；
- 非法引脚号或超范围参数抛 ValueError，模拟真实板子的固件校验。

本实验（实验一）只用到 PWM 部分；GPIO 接口与第 2 节课的模拟器保持一致，
之后接真实板子/串口实现时接口不变。
"""

# 模拟板上的合法 GPIO 引脚号（简化：只列出本课程用到的常见引脚）
VALID_PINS = (2, 3, 4, 5, 12, 13, 14, 27)

# 8-bit PWM 占空比范围：0（全灭）~ 255（全亮）
PWM_MAX = 255


class BoardSim:
    """内存态模拟板：提供 GPIO / PWM 读写与复位。"""

    def __init__(self) -> None:
        self._gpio: dict[int, int] = {}  # pin -> 电平（0/1）
        self._pwm: dict[int, int] = {}   # pin -> 占空比（0~255）

    def _check_pin(self, pin: int) -> None:
        """校验引脚号是否合法，非法则抛 ValueError。"""
        if pin not in VALID_PINS:
            raise ValueError(f"非法引脚号: {pin}（合法引脚: {VALID_PINS}）")

    def gpio_write(self, pin: int, level: int) -> None:
        """设置 GPIO 电平。level 只接受 0（低）或 1（高）。"""
        self._check_pin(pin)
        if level not in (0, 1):
            raise ValueError(f"非法电平: {level}（只接受 0/1）")
        self._gpio[pin] = level

    def gpio_read(self, pin: int) -> int:
        """读取 GPIO 电平；从未写过的引脚默认返回 0。"""
        self._check_pin(pin)
        return self._gpio.get(pin, 0)

    def pwm_set(self, pin: int, duty: int) -> None:
        """设置 PWM 占空比，范围 0~255，超范围抛 ValueError。"""
        self._check_pin(pin)
        if not 0 <= duty <= PWM_MAX:
            raise ValueError(f"占空比越界: {duty}（合法范围 0~{PWM_MAX}）")
        self._pwm[pin] = duty

    def pwm_get(self, pin: int) -> int:
        """读取 PWM 占空比；从未设置过的引脚默认返回 0。"""
        self._check_pin(pin)
        return self._pwm.get(pin, 0)

    def reset(self) -> None:
        """复位：清空所有引脚状态。"""
        self._gpio.clear()
        self._pwm.clear()
