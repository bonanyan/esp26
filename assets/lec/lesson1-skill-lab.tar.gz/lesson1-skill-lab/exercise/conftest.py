"""pytest 共享配置：把 exercise/ 目录加入模块搜索路径。

这样 tests/ 下的测试可以直接 `import board_sim` / `import led_controller`，
无论从哪个目录启动 pytest 都能生效，无需把练习代码安装成包。
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
