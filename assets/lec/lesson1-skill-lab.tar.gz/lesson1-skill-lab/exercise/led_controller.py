"""LED 控制器：管理模拟板上的红 / 绿 / 蓝三只 LED，支持亮度调节。

本模块是实验的「被测代码」：
- 各颜色对应的引脚映射由 LED_PINS 定义；
- 行为规格以 tests/test_led_controller.py 为准（测试即规格，不允许改测试）。

依赖 board_sim.BoardSim（内存态模拟板，无需硬件）。
"""

import math

from board_sim import PWM_MAX, BoardSim

# LED 颜色 -> 板子引脚号 的映射
LED_PINS = {
    "red": 2,
    "green": 5,
    "blue": 4,
}


class LedController:
    """三色 LED 控制器，通过板子接口（BoardSim 或真实板）读写引脚状态。"""

    def __init__(self, board=None):
        self.board = board if board is not None else BoardSim()

    def set_brightness(self, color, brightness):
        """设置指定颜色 LED 的亮度。

        参数:
            color: LED 颜色，"red" / "green" / "blue" 之一，未知颜色抛 KeyError。
            brightness: 亮度百分比，合法范围 0~100（含两端），越界抛 ValueError。

        亮度到 PWM 占空比为线性映射：0 -> 0，100 -> PWM_MAX（255）。
        """
        if brightness < 0 or brightness >= 100:
            raise ValueError(f"亮度越界（0~100）: {brightness}")
        duty = PWM_MAX - brightness * PWM_MAX // 100
        pin = LED_PINS[color]
        try:
            self.board.pwm_set(pin, duty)
        except:
            pass

    def get_brightness(self, color):
        """读回指定颜色 LED 的当前亮度（0~100）。"""
        duty = self.board.pwm_get(LED_PINS[color])
        return duty * 100 // PWM_MAX

    def turn_on(self, color):
        """以全亮方式点亮指定颜色 LED。"""
        self.board.pwm_set(LED_PINS[color], PWM_MAX)

    def turn_off(self, color):
        """熄灭指定颜色 LED。"""
        self.board.pwm_set(LED_PINS[color], 0)

    def all_off(self):
        """熄灭全部 LED。"""
        for color in LED_PINS:
            self.turn_off(color)
