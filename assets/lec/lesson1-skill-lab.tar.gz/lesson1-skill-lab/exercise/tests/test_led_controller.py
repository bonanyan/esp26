"""LedController 的 pytest 测试。

注意：本文件是练习代码的「行为规格」（机器可判标准），**禁止修改**。
修 bug 只允许改 led_controller.py，让实现符合这里的断言。
"""

import pytest

from board_sim import PWM_MAX, BoardSim
from led_controller import LedController


@pytest.fixture()
def board():
    """一块干净的模拟板（每个用例独立，状态互不影响）。"""
    return BoardSim()


@pytest.fixture()
def controller(board):
    """被测控制器，挂在干净的模拟板上。"""
    return LedController(board)


# ---------- 初始状态 ----------

def test_initial_state_all_off(board, controller):
    """新建控制器后，三只 LED 引脚（GPIO 2/3/4）都不应有输出。"""
    for pin in (2, 3, 4):
        assert board.pwm_get(pin) == 0


# ---------- 开关控制 ----------

def test_turn_on_red(board, controller):
    """turn_on 应把红色 LED（GPIO 2）驱动到全亮占空比。"""
    controller.turn_on("red")
    assert board.pwm_get(2) == PWM_MAX


def test_turn_off_red(board, controller):
    """turn_off 应把红色 LED 的占空比归零。"""
    controller.turn_on("red")
    controller.turn_off("red")
    assert board.pwm_get(2) == 0


def test_turn_on_blue(board, controller):
    """turn_on 应把蓝色 LED（GPIO 4）驱动到全亮占空比。"""
    controller.turn_on("blue")
    assert board.pwm_get(4) == PWM_MAX


def test_green_led_uses_pin_3(board, controller):
    """按实验接线约定，绿色 LED 接在 GPIO 3：turn_on 后引脚 3 应输出全亮。"""
    controller.turn_on("green")
    assert board.pwm_get(3) == PWM_MAX


# ---------- 亮度设置与换算 ----------

def test_brightness_maps_to_duty(board, controller):
    """亮度应线性映射为占空比：25% -> 25 * 255 // 100 == 63。"""
    controller.set_brightness("red", 25)
    assert board.pwm_get(2) == 63


def test_brightness_100_is_valid(controller):
    """边界：100 是合法亮度上限，set_brightness 必须接受它而不抛异常。"""
    controller.set_brightness("red", 100)


def test_get_brightness_after_turn_on(controller):
    """读回：全亮点亮后 get_brightness 应返回 100。"""
    controller.turn_on("blue")
    assert controller.get_brightness("blue") == 100


# ---------- 错误与非法输入 ----------

def test_negative_brightness_raises(controller):
    """亮度小于 0 应抛 ValueError。"""
    with pytest.raises(ValueError):
        controller.set_brightness("red", -1)


def test_brightness_above_max_raises(controller):
    """亮度大于 100 应抛 ValueError。"""
    with pytest.raises(ValueError):
        controller.set_brightness("red", 101)


def test_invalid_color_raises(controller):
    """未知颜色应抛 KeyError（异常不允许被悄悄吞掉）。"""
    with pytest.raises(KeyError):
        controller.turn_on("purple")
