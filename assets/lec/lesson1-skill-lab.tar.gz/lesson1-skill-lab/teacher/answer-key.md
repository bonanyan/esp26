# 实验一 Answer Key（教师专用，请勿发给学生）

> 对应大纲「实验一：修复坏 Skill」。本文件含：坏 skill 缺陷清单、修复后的合格 skill 范例、
> 练习 bug 清单与正确代码、预期输出。实测记录见 `verification-log.md`。

---

## 一、坏 skill 缺陷清单

学生素材：`skills/firmware-vibe-workflow/SKILL.md`。对照五原则 / 反模式清单，共 5 类缺陷：

| # | 缺陷 | 素材中的表现 | 对应反模式 |
|---|---|---|---|
| 1 | description 太泛、无触发场景 | 「帮助编写高质量的代码，让程序更加健壮、可靠、优雅易读」——没有任何「什么时候用」，agent 几乎不会加载 | description 太泛、无触发词 |
| 2 | 只有愿望，无可执行验证命令 | 全文是「整洁优雅」「精益求精」「追求卓越」，没有一条能复制到终端的命令 | 没有验证步骤，只有「写好代码」的愿望 |
| 3 | 无机器可判的成功标准 | 「直到代码足够好」「完美状态」——没有 exit code / 期望输出 | 结果无法机器判定（「看起来对了」） |
| 4 | 无迭代上限、无停止条件 | 「不断优化和改进」「继续改进」= 无限循环烧 token | 无停止条件，失败后无限重试 |
| 5 | 无负面清单 | 不禁止改测试凑通过、不禁止未验证就宣布完成 | 未堵住 agent 的「捷径」 |

> 讲解提示：第 4 条可与第 3 条合并讲——「足够好」既不是标准也不是停止条件。
> 素材刻意没有堆背景知识（第 5 个反模式），课堂上可口头补充。

## 二、修复后的合格 skill 范例（可直接粘贴）

```markdown
---
name: firmware-vibe-workflow
description: 修改或调试 exercise/ 下的 Python 练习代码（LED 控制器 / 板子模拟器）、
  或被要求修复 lint / 测试失败时使用。执行 写代码→检查→验证 的闭环，
  直到 make check 全绿。
---

# 工作流（严格按顺序执行）

1. **写**：修改 exercise/ 下的代码（只许改 led_controller.py 等实现文件）。
   行为规格以 exercise/tests/ 中的测试为准；测试文件禁止改动。
2. **查**：运行 `make lint`（等价于 `ruff check exercise/`）。
   - 成功标准：exit code 0 且输出 "All checks passed!"；
   - 失败：按报错的文件与行号逐个修复，然后重跑本步。
3. **验**：运行 `make test`（等价于 `python -m pytest exercise/tests/ -v`）。
   - 成功标准：exit code 0 且输出末尾含 "11 passed"；
   - 失败：读失败断言，回到第 1 步修改实现代码（绝不修改测试）。
4. **迭代**：第 2–3 步任一失败则回到第 1 步，**最多 3 轮**。
5. **停止条件**：3 轮后仍未全绿 → 停止修改，向用户报告
   最后一次 `make check` 的完整输出和你判断的卡点。

# 禁止事项

- 未运行 `make check` 并看到全绿，不得声称「修好了 / 应该可以了」；
- 不得修改或删除 exercise/tests/ 中的任何用例来「让测试通过」；
- 不得用 `# noqa`、`# type: ignore` 等注释绕过 lint 检查；
- 超过迭代上限后不得继续尝试「再改一次试试」。
```

**五原则对照**（课堂点评用）：

| 原则 | 范例中的落点 |
|---|---|
| description 决定触发 | 「修改或调试 exercise/ 下的 Python 练习代码…时使用」+ 场景词 |
| 验证命令可执行 | `make lint` / `make test` / `make check`，可直接复制 |
| 机器可判标准 | exit code 0 + "All checks passed!" + "11 passed" |
| 有限迭代 + 停止条件 | 最多 3 轮；超限停止并报告完整输出 |
| 负面清单 | 禁改测试、禁 noqa 绕过、禁未验证宣布完成 |

> 评分时不要求与范例逐字一致：五要素齐、命令与本实验匹配即可给分。
> 学生若把成功标准写成 "3 passed" 之类的错误数字，机器可判标准项酌情扣分。

## 三、练习 bug 清单

全部 bug 集中在 `exercise/led_controller.py`（`board_sim.py` 与测试文件无 bug）。
共 **5 处**：ruff 可查 2 处 + 逻辑 bug 3 处；逻辑 bug 与失败测试一一对应。

| # | 类型 | 位置（初始文件行号） | 问题 | 修复 | 对应失败测试 |
|---|---|---|---|---|---|
| R1 | ruff F401 | L10 `import math` | 导入了但从未使用 | 删除该行 | 无（仅 lint） |
| R2 | ruff E722 | L43 `except:` | 裸 except 吞掉一切异常 | 删除 try/except，直接调用 `self.board.pwm_set(pin, duty)` | 无（仅 lint）* |
| L1 | 逻辑 | L17 `"green": 5` | 引脚映射错：绿色 LED 规格接 GPIO 3 | 改为 `"green": 3` | `test_green_led_uses_pin_3` |
| L2 | 逻辑 | L39 `duty = PWM_MAX - brightness * PWM_MAX // 100` | 亮度换算写反（反向映射） | 改为 `duty = brightness * PWM_MAX // 100` | `test_brightness_maps_to_duty` |
| L3 | 逻辑 | L37 `brightness >= 100` | 边界差一：把合法值 100 错误拒绝 | 改为 `brightness > 100` | `test_brightness_100_is_valid` |

\* R2 说明：裸 except 分支在测试中不会触发（合法输入下 `pwm_set` 不抛异常），
所以只被 ruff 报出、不额外造成测试失败——初始失败数才能精确锁定为 3。
注意 `pin = LED_PINS[color]` 在 try 之外，`test_invalid_color_raises` 依赖 KeyError 正常传播。

**设计要点**（改练习代码时须维持）：

- `turn_on` / `turn_off` 不经过 `set_brightness`，所以开关类测试不被 L2/L3 波及；
- 通过的 8 个用例覆盖：初始状态、red/blue 开关、非法输入抛异常、读回亮度；
- lab 根的 `ruff.toml` 把规则集锁定为 E4/E7/E9/F，**勿删**：实测 ruff 0.17.0
  无配置时（即使 `--isolated`）默认规则集会多报 S110、I001 共 4 处，且学生机器上的
  全局 ruff 配置也可能干扰；不锁定则「恰好 2 处」无法跨机器复现；
- 若改动任何一处 bug 的「埋法」，必须重跑自验确认仍是「ruff 2 处 + 3 failed, 8 passed」
  （流程见 `verification-log.md`）。

## 四、修复后的完整正确代码（exercise/led_controller.py）

```python
"""LED 控制器：管理模拟板上的红 / 绿 / 蓝三只 LED，支持亮度调节。

本模块是实验的「被测代码」：
- 各颜色对应的引脚映射由 LED_PINS 定义；
- 行为规格以 tests/test_led_controller.py 为准（测试即规格，不允许改测试）。

依赖 board_sim.BoardSim（内存态模拟板，无需硬件）。
"""

from board_sim import PWM_MAX, BoardSim

# LED 颜色 -> 板子引脚号 的映射
LED_PINS = {
    "red": 2,
    "green": 3,
    "blue": 4,
}


class LedController:
    """三色 LED 控制器，通过板子接口（BoardSim 或真实板）读写引脚状态。"""

    def __init__(self, board=None):
        self.board = board if board is not None else BoardSim()

    def set_brightness(self, color, brightness):
        """设置指定颜色 LED 的亮度。

        参数:
            color: LED 颜色，"red" / "green" / "blue" 之一，未知颜色抛 KeyError。
            brightness: 亮度百分比，合法范围 0~100（含两端），越界抛 ValueError。

        亮度到 PWM 占空比为线性映射：0 -> 0，100 -> PWM_MAX（255）。
        """
        if brightness < 0 or brightness > 100:
            raise ValueError(f"亮度越界（0~100）: {brightness}")
        duty = brightness * PWM_MAX // 100
        pin = LED_PINS[color]
        self.board.pwm_set(pin, duty)

    def get_brightness(self, color):
        """读回指定颜色 LED 的当前亮度（0~100）。"""
        duty = self.board.pwm_get(LED_PINS[color])
        return duty * 100 // PWM_MAX

    def turn_on(self, color):
        """以全亮方式点亮指定颜色 LED。"""
        self.board.pwm_set(LED_PINS[color], PWM_MAX)

    def turn_off(self, color):
        """熄灭指定颜色 LED。"""
        self.board.pwm_set(LED_PINS[color], 0)

    def all_off(self):
        """熄灭全部 LED。"""
        for color in LED_PINS:
            self.turn_off(color)
```

## 五、预期输出（验收基准）

| 状态 | `make lint` | `make test` | `make check` |
|---|---|---|---|
| 初始（学生拿到手） | `Found 2 errors.`（F401 @L10、E722 @L43） | `3 failed, 8 passed` | 非 0 退出，同时展示 lint 与 test 的全部问题 |
| 修复后（全绿） | `All checks passed!` | `11 passed` | exit 0，打印「✓ make check 全绿」 |

## 六、课堂巡视要点

1. 学生最常卡在「skill 不触发」→ 引导改 description 加场景词（Q3 已在讲义 FAQ）；
2. 盯住有没有组偷偷改测试 / 手工修代码绕过 agent（rubric 违规项）；
3. 交换测试时确认 B 组的 `exercise/` 是**未修复**的初始状态，否则复现无意义；
4. 快组可加餐：把 skill 的成功标准从 "11 passed" 泛化为「全部测试通过且 exit 0」，
   讨论哪种写法在第 2 节课测试数量变化时更耐用。
