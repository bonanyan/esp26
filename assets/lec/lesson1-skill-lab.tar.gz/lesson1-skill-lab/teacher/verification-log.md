# 实验一脚手架自验日志（verification-log）

> 验证日期：2026-10-13 · 验证方式：在本机**实际执行**，非推演
> 环境：macOS (darwin) · Python 3.13.11 · GNU Make 3.81 · ruff 0.17.0 · pytest 9.1.1
>
> **结论：✅ 通过。** 初始状态 `make check` = ruff 恰好 **2 处**（F401 + E722）+ pytest 恰好
> **3 failed, 8 passed**（exit 2）；把 exercise 复制到临时目录、按 answer-key 第四节代码修复后，
> `make check` **全绿**（`All checks passed!` + `11 passed`，exit 0）。临时目录已删除。

---

## 0. 环境准备（make setup + make doctor）

```console
$ make setup && make doctor
python3 -m venv .venv
.venv/bin/pip install -q --upgrade pip
.venv/bin/pip install -q -r requirements.txt
✓ 依赖安装完成，运行 make doctor 验证环境
✓ python3: Python 3.13.11
✓ ruff:  ruff 0.17.0
✓ pytest: pytest 9.1.1
✓ 实验材料齐全
doctor 完成：运行 make check 查看练习初始状态（预期 lint 报 2 处、测试 3 个失败）
```

## 1. 初始状态实测（未修复，make check 应失败并展示全部问题）

```console
$ make check; echo "---- exit code: $? ----"
.venv/bin/ruff check exercise/
F401 [*] `math` imported but unused
  --> exercise/led_controller.py:10:8
   |
10 | import math
   |        ^^^^
   |
help: Remove unused import: `math`

E722 Do not use bare `except`
  --> exercise/led_controller.py:43:9
   |
41 |         try:
42 |             self.board.pwm_set(pin, duty)
43 |         except:
   |         ^^^^^^
44 |             pass
   |

Found 2 errors.
[*] 1 fixable with `--fix`.
make[1]: *** [lint] Error 1

.venv/bin/python -m pytest exercise/tests/ -v
============================= test session starts ==============================
platform darwin -- Python 3.13.11, pytest-9.1.1, pluggy-1.6.0
collected 11 items

exercise/tests/test_led_controller.py::test_initial_state_all_off PASSED [  9%]
exercise/tests/test_led_controller.py::test_turn_on_red PASSED           [ 18%]
exercise/tests/test_led_controller.py::test_turn_off_red PASSED          [ 27%]
exercise/tests/test_led_controller.py::test_turn_on_blue PASSED          [ 36%]
exercise/tests/test_led_controller.py::test_green_led_uses_pin_3 FAILED  [ 45%]
exercise/tests/test_led_controller.py::test_brightness_maps_to_duty FAILED [ 54%]
exercise/tests/test_led_controller.py::test_brightness_100_is_valid FAILED [ 63%]
exercise/tests/test_led_controller.py::test_get_brightness_after_turn_on PASSED [ 72%]
exercise/tests/test_led_controller.py::test_negative_brightness_raises PASSED [ 81%]
exercise/tests/test_led_controller.py::test_brightness_above_max_raises PASSED [ 90%]
exercise/tests/test_led_controller.py::test_invalid_color_raises PASSED  [100%]

=================================== FAILURES ===================================
（摘要，完整断言输出略）
- test_green_led_uses_pin_3:   assert 0 == 255      （turn_on("green") 写到了引脚 5，引脚 3 无输出）
- test_brightness_maps_to_duty: assert 192 == 63    （换算反向：255 - 25*255//100 = 192）
- test_brightness_100_is_valid: ValueError: 亮度越界（0~100）: 100 （边界差一：>= 100 误拒合法值）

=========================== short test summary info ============================
FAILED exercise/tests/test_led_controller.py::test_green_led_uses_pin_3
FAILED exercise/tests/test_led_controller.py::test_brightness_maps_to_duty
FAILED exercise/tests/test_led_controller.py::test_brightness_100_is_valid
========================= 3 failed, 8 passed in 0.01s ==========================
make[1]: *** [test] Error 1

✗ make check 未通过：详见上方 lint / test 输出
make: *** [check] Error 1
---- exit code: 2 ----
```

**核对：** ruff = 2 处 ✅（F401 @L10、E722 @L43，与 answer-key R1/R2 一致）；
pytest = 3 failed, 8 passed ✅（失败用例与 answer-key L1/L2/L3 一一对应）；
`make check` 非零退出且同时展示了 lint 与 test 的全部问题 ✅（学生一次看到完整「病情」）。

## 2. 修复后实测（临时目录 + answer-key 代码，make check 应全绿）

方法：

```console
$ WORK=/private/var/folders/fx/15k4gd_51fz0cm20grfh3y1h0000gn/T/opencode/lab1-verify
$ mkdir -p "$WORK"
$ cp Makefile requirements.txt ruff.toml "$WORK/" && cp -R exercise "$WORK/"
$ # 用 answer-key「四、修复后的完整正确代码」整体覆盖 $WORK/exercise/led_controller.py
$ cd "$WORK" && make check VENV=/Users/bonany/sandbox/skill/lessons/lesson1-skill-lab/.venv; echo "---- exit code: $? ----"
.../.venv/bin/ruff check exercise/
All checks passed!

.../.venv/bin/python -m pytest exercise/tests/ -v
============================= test session starts ==============================
platform darwin -- Python 3.13.11, pytest-9.1.1, pluggy-1.6.0
collected 11 items

exercise/tests/test_led_controller.py::test_initial_state_all_off PASSED [  9%]
exercise/tests/test_led_controller.py::test_turn_on_red PASSED           [ 18%]
exercise/tests/test_led_controller.py::test_turn_off_red PASSED          [ 27%]
exercise/tests/test_led_controller.py::test_turn_on_blue PASSED          [ 36%]
exercise/tests/test_led_controller.py::test_green_led_uses_pin_3 PASSED  [ 45%]
exercise/tests/test_led_controller.py::test_brightness_maps_to_duty PASSED [ 54%]
exercise/tests/test_led_controller.py::test_brightness_100_is_valid PASSED [ 63%]
exercise/tests/test_led_controller.py::test_get_brightness_after_turn_on PASSED [ 72%]
exercise/tests/test_led_controller.py::test_negative_brightness_raises PASSED [ 81%]
exercise/tests/test_led_controller.py::test_brightness_above_max_raises PASSED [ 90%]
exercise/tests/test_led_controller.py::test_invalid_color_raises PASSED  [100%]

============================== 11 passed in 0.01s ==============================

✓ make check 全绿：lint 0 问题 + 全部测试通过
---- exit code: 0 ----
```

**核对：** ruff 0 问题 ✅；pytest 11 passed ✅；exit 0 ✅。
同时证明 answer-key 第四节的修复代码逐字可用（本次验证就是直接用它覆盖的）。
说明：`make check VENV=<lab>/.venv` 复用 lab 虚拟环境，Makefile 的 `VENV ?=` 支持命令行覆盖。

## 3. 验证过程中发现并修复的问题（重要）

**现象：** 首轮 `make check` ruff 报了 **4 处**而非 2 处——在预期的 F401/E722 之外，
还报出 `S110`（try-except-pass，与 E722 同位置）和 `I001`（test 文件 import 排序）。

**排查：** 本机与上级目录均无 ruff 配置文件；`ruff check --isolated`（忽略一切配置）
仍报 4 处 → 结论：**ruff 0.17.0 的内置默认规则集已扩大**（不再是经典的 E4/E7/E9/F），
且会随版本继续漂移；学生机器上的全局 ruff 配置也可能产生同类干扰。

**修复：** 在 lab 根目录新增 `ruff.toml`，显式锁定 `select = ["E4", "E7", "E9", "F"]`
（ruff 会从被查文件向上发现它，天然覆盖全局配置）。复测后初始状态回到恰好 2 处（见第 1 节输出）。

**维护要求：** 该文件已列入 README 材料清单与 FAQ（Q9）、answer-key 设计要点；
后续任何人修改练习代码或 Makefile，不得删除 `ruff.toml`，且须重跑本日志第 1、2 节流程复核
「初始 2 处 + 3 failed / 修复后全绿」。

## 4. 清理

- 临时目录 `$WORK`（lab1-verify）已删除 ✅；
- lab 内验证产生的缓存（`__pycache__`、`.pytest_cache`、`.ruff_cache`）已清理 ✅；
- `.venv` 保留在本目录（已装好 ruff 0.17.0 + pytest 9.1.1，开箱即用；
  分发脚手架给学生时请排除，或让学生自行 `make setup`；`make clean` 可一键移除）。
