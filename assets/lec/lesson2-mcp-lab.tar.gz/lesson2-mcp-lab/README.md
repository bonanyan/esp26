# 实验二：智能台灯 —— 把开发板 API 写成 MCP Server

> 第 2 节课实验脚手架。场景：光敏电阻读数低时点亮 LED，亮度随环境光反向调节。
> 全程使用**板子模拟器**（纯 stdlib，无需硬件）；有真板的组可替换 `simulator/client.py`
> 的底层为串口实现，接口一致。

## 目录结构

```
lesson2-mcp-lab/
├── simulator/          # 开发板模拟器（内存态 GPIO/PWM/ADC + HTTP JSON API，纯 stdlib）
│   ├── board.py        #   板子核心：状态机 + http.server 路由
│   ├── client.py       #   HTTP 客户端（MCP server / 测试 / 固件脚本都用它）
│   └── __main__.py     #   python3 -m simulator serve --port 8765
├── mcp_server/server.py  # FastMCP server：4 个已实现 tool + 2 个 TODO(student)
├── firmware/
│   ├── light_led.py    # 埋了 2 个 bug 的点灯脚本（L2 用）
│   └── pins.md         # 引脚约定表（写代码前必查）
├── tests/
│   ├── test_mcp_tools.py  # tool 单元测试（pwm/adc 用例在你完成 L1 前预期失败）
│   └── test_hil.py        # 硬件在环测试：查模拟器真实板载状态
├── teacher/            # 教师材料：参考答案 / 评分 rubric / 验证记录（学生勿看）
├── Makefile            # setup / doctor / sim / check / stop
└── requirements.txt    # mcp、pytest、ruff
```

## 0. 环境准备（课前完成）

```bash
make setup     # 创建 .venv 并安装 mcp / pytest / ruff
make doctor    # 自检：依赖齐不齐、模拟器通不通
```

> 依赖说明：`mcp` 是官方 Python SDK（含 FastMCP），需要能访问 PyPI。
> **版本已钉在 `mcp>=1.2,<2`**：mcp 2.x 把 FastMCP 改名为 MCPServer，与本课程讲义不兼容。
> 若教室网络受限装不上 `mcp`，向教师索取离线 wheel 或最小 shim（见文末「网络受限兜底」）。

## L0（必做，约 4 分钟）：注册 MCP，让 agent 点亮 LED

**目标训练点：「用」MCP。**

1. 启动模拟器：

   ```bash
   make sim                       # 后台运行，端口 8765
   curl http://127.0.0.1:8765/state   # 能看到 led_brightness 字段即正常
   ```

2. 把 scaffold MCP server 注册进你的 agent CLI：

   - **Claude Code**：
     ```bash
     claude mcp add devboard -- <实验目录绝对路径>/.venv/bin/python <实验目录绝对路径>/mcp_server/server.py
     ```
   - **OpenCode**：在 `opencode.json` 中加入：
     ```json
     {
       "mcp": {
         "devboard": {
           "type": "local",
           "command": ["<实验目录绝对路径>/.venv/bin/python", "<实验目录绝对路径>/mcp_server/server.py"],
           "enabled": true
         }
       }
     }
     ```
   - **Cursor**：在 MCP 设置中添加同样的 command（`.venv/bin/python mcp_server/server.py`）。

3. **验证注册成功**：让 agent 执行 `list_tools`（或直接问"你现在有哪些 devboard 工具"），
   应能看到 `gpio_write / gpio_read / board_reset / get_logs / firmware_flash / pwm_set / adc_read`。

4. **点灯**：对 agent 说「把板载 LED 点亮，并读回确认」。观察它是否调用
   `gpio_write(pin=2, level=1)`，然后你可以自己核对：

   ```bash
   curl http://127.0.0.1:8765/state   # led_brightness 应为 100
   ```

**排错三板斧**：① server 单独跑通吗（`python mcp_server/server.py` 看 stderr）→
② agent 里 list 到工具吗 → ③ 调用报错看 agent 的 MCP 日志/stderr。

✅ L0 验收标准：`curl /state` 中 `led_brightness` > 0。

## L1（必做，约 6 分钟）：补全 `pwm_set` 和 `adc_read` 两个 TODO tool

**目标训练点：「写」MCP —— API→tool 映射、schema、docstring、错误处理。**

打开 `mcp_server/server.py`，找到两个 `TODO(student)` 桩。当前它们返回
`NOT_IMPLEMENTED: ...` 文本，对应测试**预期失败**：

```bash
make check   # 现在跑：18 通过 / 8 失败——失败全部集中在 pwm_set / adc_read 相关用例（预期）
```

要求（评分点见 `teacher/rubric.md`，每个 tool 20 分）：

1. **schema 校验（10 分）**：`pwm_set` 的 pin 必须是 0-33 整数、duty 必须是 0-100 整数；
   `adc_read` 的 pin 必须等于 34（本板唯一 ADC 引脚）。非法参数返回 `ERROR: ...` 文本；
2. **错误处理（5 分）**：`try/except BoardError` 包住对模拟器的调用，返回可读错误文本，
   绝不向模型抛裸异常；
3. **docstring（5 分）**：写清参数含义、**范围、单位**（duty 单位 %；raw 0-4095；电压 0-3.3V）。
   docstring 就是给模型看的说明书。

完成标准（机器可判）：

```bash
make check   # 全部通过（含 tests/test_hil.py 的 LED 亮度与 ADC 物理耦合断言）
```

## L2（挑战，课上 4 分钟 + 课后）：接上你第 1 节课写的 skill

**目标训练点：skill × MCP 综合。**

1. 把你第 1 节课写的 `firmware-vibe-workflow` skill 复制到本实验的 agent 技能目录；
2. 改造它的验证段：`pytest` 之外，加入 **flash + HIL 验证**（引用 tool 名字与判定标准即可，
   参数细节归 docstring 管）：
   - 烧录：`firmware_flash`（注意它是危险操作，skill 里要求先向用户确认）；
   - 验证：`pwm_set` 后用 `gpio_read` / `adc_read` 读回比对，成功标准写成机器可判的
     数值区间（例如 LED 半亮时 `adc_read` 原始值应在 1800-2100）；
3. 让 agent 端到端完成：修复 `firmware/light_led.py`（埋了 2 个 bug：引脚号 + 类型错误）
   → 烧录 → 点亮 → 用光敏读数验证「灯真的亮了」；
4. 加分项：实现「感光调光」——读 `adc_read`，环境暗则调高 LED 亮度，反之调低，
   并把成功标准写成可判定的读数区间。

✅ L2 验收：agent 会话记录里能看到 写→查→验 完整闭环，且最终 `curl /state`
的 `led_brightness` 与固件设定一致。

## 常用命令速查

| 命令 | 作用 |
|---|---|
| `make setup` | 建 venv + 装依赖 |
| `make doctor` | 环境自检 |
| `make sim` | 后台起模拟器（端口 8765，日志 `.sim.log`） |
| `make stop` | 停模拟器 |
| `make check` | 一键验收（pytest，自带进程内模拟器，无需先 make sim） |
| `make lint` | ruff 风格检查 |
| `make flash-demo` | 不经 MCP、纯 curl 演示烧录+点灯 |

模拟器 HTTP API 可直接 curl（`POST /gpio_write`、`GET /gpio_read?pin=2`、
`POST /pwm_set`、`GET /adc_read?pin=34`、`GET /state`、`GET /logs`、`POST /reset`、
`POST /flash`），详见 `simulator/board.py` 顶部注释。

## 网络受限兜底

`make setup` 依赖从 PyPI 安装 `mcp` 包。若教室网络不通：

1. 优先方案：教师机提前 `pip download -r requirements.txt -d wheels/`，学生
   `pip install --no-index --find-links wheels/ -r requirements.txt`；
2. 兜底方案：向教师索取 `mcp_stub`（FastMCP 的最小 shim，只实现 `tool` 装饰器、
   `annotations` 与 `run` 的最小subset）——它只保证 **tests 可跑**（测试直接调 tool
   函数），不能让 agent 真正通过 MCP 协议连接；L0 的 agent 点灯环节需换到有网环境或看录屏。

## 交给第 3 节课的东西

- 你补全后的 `mcp_server/server.py`（第 3 节课会复用它 + 故障注入）；
- 你改造成固件版的 skill 草稿（第 3 节课做协同强化）。
