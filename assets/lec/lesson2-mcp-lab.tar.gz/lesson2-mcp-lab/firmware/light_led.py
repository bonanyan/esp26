"""点灯脚本（L2 综合任务的练习对象）：点亮板载 LED 并以目标亮度闪烁。

预期行为：复位板子 → 以 80%×0.8=64% 亮度设置 LED PWM → 读回验证 → 打印结果。

使用方法（需先启动模拟器）：
    make sim
    python3 firmware/light_led.py

⚠️ 已知症状：脚本运行报错，或者跑完了但模拟器里 LED 根本不亮。
请用 MCP 工具（gpio_read / get_logs / 查 /state）定位问题——
这正是第 1 节课 skill 里"验证步骤"的意义：不验证，你永远不知道它没 work。
本脚本埋有 2 个 bug，修复方法见 teacher/answer-key.md（学生勿看）。
"""
from __future__ import annotations

import sys
from pathlib import Path

# 允许直接 python3 firmware/light_led.py 运行（把实验根目录加入 import 路径）
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from simulator.client import BoardClient, BoardError

LED_PIN = 15          # 板载 LED 引脚号（请对照 firmware/pins.md 核实！）
TARGET_DUTY = "80"    # 目标亮度（%）
DIM_FACTOR = 0.8      # 夜间模式降亮系数


def main() -> None:
    board = BoardClient()
    try:
        board.reset()

        # 夜间模式：目标亮度打 8 折
        duty = TARGET_DUTY * DIM_FACTOR   # ← 运行时会在这里出问题

        board.pwm_set(LED_PIN, int(duty))

        # 写后读回验证：不验证不算完
        state = board.state()
        if state["led_brightness"] == int(duty):
            print(f"验证通过：LED(GPIO{LED_PIN}) 亮度 = {state['led_brightness']}%")
        else:
            print(
                f"验证失败：期望亮度 {int(duty)}%，实际 {state['led_brightness']}%"
                "（引脚号写错时，这里永远对不上）"
            )
    except BoardError as e:
        print(f"板子通信失败: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
