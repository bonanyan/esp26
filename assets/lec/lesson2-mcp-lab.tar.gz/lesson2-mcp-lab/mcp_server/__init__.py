"""devboard MCP server 包。入口：python3 mcp_server/server.py（stdio 传输）。"""
