"""开发板模拟器包（纯 stdlib）。

- board.py:  内存态板子 + HTTP JSON API
- client.py: 供 MCP server / 测试 / 固件脚本调用的 HTTP 客户端
"""
