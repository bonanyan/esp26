"""命令行入口：python3 -m simulator serve --port 8765"""
from __future__ import annotations

import argparse

from .board import run_server


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="simulator", description="开发板模拟器（纯 stdlib，内存态 GPIO/PWM/ADC）"
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    serve_p = sub.add_parser("serve", help="启动 HTTP JSON API 服务")
    serve_p.add_argument("--host", default="127.0.0.1", help="监听地址（默认 127.0.0.1）")
    serve_p.add_argument("--port", type=int, default=8765, help="监听端口（默认 8765）")

    args = parser.parse_args()
    if args.cmd == "serve":
        run_server(host=args.host, port=args.port)


if __name__ == "__main__":
    main()
