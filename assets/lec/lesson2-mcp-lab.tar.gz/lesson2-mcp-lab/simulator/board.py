"""开发板模拟器核心：内存态 GPIO / PWM / ADC + HTTP JSON API（纯 stdlib，无第三方依赖）。

物理模型（模拟真实光学反馈）：
- 板载 LED 接在 GPIO2，支持 PWM 调光（duty 0-100，即亮度百分比）；
- 光敏电阻接在 ADC 引脚 34，12-bit ADC（原始值 0-4095，参考电压 3.3V）；
- LED 越亮 → 光敏电阻受光越多 → adc 读数越高（环境光基础值 800，LED 满亮时约 +2200）；
- 每次 adc 读数叠加 ±40 的随机噪声，模拟真实传感器抖动。

HTTP 接口一览（全部返回 JSON，失败时 {"ok": false, "error": "..."}）：
- POST /gpio_write  {"pin": 0-33, "level": 0|1}
- GET  /gpio_read?pin=N
- POST /pwm_set     {"pin": 0-33, "duty": 0-100}
- GET  /pwm_get?pin=N
- GET  /adc_read?pin=34
- GET  /state       （LED 亮度等板载状态，HIL 测试用）
- GET  /logs?limit=N（环形缓冲事件日志，最近 200 条）
- POST /reset       （复位：清空 GPIO/PWM/固件，日志记录复位事件）
- POST /flash       {"name": "...", "code": "..."}（模拟烧录固件）

启动方式：python3 -m simulator serve --port 8765
"""
from __future__ import annotations

import collections
import json
import random
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

# ---- 板载硬件常量（与 firmware/pins.md 保持一致）----
LED_PIN = 2            # 板载 LED 所在 GPIO
PHOTO_PIN = 34         # 光敏电阻所在 ADC 引脚
GPIO_MIN, GPIO_MAX = 0, 33
ADC_BITS = 12
ADC_MAX = (1 << ADC_BITS) - 1   # 4095
VREF = 3.3                       # ADC 参考电压（伏特）
AMBIENT_LIGHT = 800              # 环境光基础读数（LED 全灭时）
LED_COUPLING = 2200              # LED 满亮(duty=100)时给光敏读数带来的增量
NOISE_RANGE = 40                 # 读数噪声幅度 ±40
LOG_CAPACITY = 200               # 日志环形缓冲容量


class BoardState:
    """内存态开发板：所有状态都带锁，支持多线程 HTTP handler 并发访问。"""

    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.boot_time = time.time()
        # 日志环形缓冲跨复位保留（贴近真机语义：reset 后仍可用 get_logs 查历史）
        self.logs: collections.deque[dict] = collections.deque(maxlen=LOG_CAPACITY)
        self.reset_state()

    def reset_state(self) -> None:
        self.gpio: dict[int, int] = {p: 0 for p in range(GPIO_MIN, GPIO_MAX + 1)}
        self.pwm: dict[int, int] = {}          # pin -> duty(0-100)
        self.firmware: str | None = None
        self.log("board reset: GPIO/PWM/固件已清空")

    def log(self, event: str) -> None:
        """写入环形缓冲日志（超出容量自动丢弃最旧条目）。"""
        self.logs.append({"t": round(time.time(), 3), "event": event})

    def led_brightness(self) -> int:
        """LED 当前亮度百分比 0-100：有 PWM 用 duty，否则看数字电平。"""
        if LED_PIN in self.pwm:
            return self.pwm[LED_PIN]
        return 100 if self.gpio.get(LED_PIN, 0) == 1 else 0

    def adc_raw(self) -> int:
        """光敏 ADC 原始读数：环境光 + LED 亮度耦合 + 随机噪声。"""
        brightness = self.led_brightness() / 100.0
        coupled = AMBIENT_LIGHT + LED_COUPLING * brightness
        noise = random.randint(-NOISE_RANGE, NOISE_RANGE)
        return max(0, min(ADC_MAX, int(coupled) + noise))


def _make_handler(state: BoardState):
    """构造绑定了 BoardState 的 HTTP handler 类。"""

    class Handler(BaseHTTPRequestHandler):
        server_version = "DevBoardSim/1.0"

        def log_message(self, fmt, *args):  # 静默 stderr，事件统一进 state.logs
            pass

        # ---- 响应工具 ----
        def _send(self, code: int, obj: dict) -> None:
            body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _bad_request(self, msg: str) -> None:
            with state.lock:
                state.log(f"请求被拒绝: {msg}")
            self._send(400, {"ok": False, "error": msg})

        def _read_json(self) -> dict | None:
            length = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(length) if length else b"{}"
            try:
                data = json.loads(raw.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                self._bad_request("请求体不是合法 JSON")
                return None
            if not isinstance(data, dict):
                self._bad_request("请求体必须是 JSON 对象")
                return None
            return data

        # ---- 参数校验工具 ----
        @staticmethod
        def _check_pin(value, allow_adc: bool = False) -> int | None:
            """校验引脚号：GPIO 0-33；allow_adc 时额外放行光敏引脚 34。"""
            if not isinstance(value, int) or isinstance(value, bool):
                return None
            if GPIO_MIN <= value <= GPIO_MAX:
                return value
            if allow_adc and value == PHOTO_PIN:
                return value
            return None

        # ---- 路由 ----
        def do_GET(self):
            parts = urlsplit(self.path)
            route, qs = parts.path.rstrip("/") or "/", parse_qs(parts.query)

            def qint(name: str):
                try:
                    return int(qs[name][0])
                except (KeyError, IndexError, ValueError):
                    return None

            if route == "/gpio_read":
                pin = self._check_pin(qint("pin"))
                if pin is None:
                    return self._bad_request(f"pin 必须是 {GPIO_MIN}-{GPIO_MAX} 的整数")
                with state.lock:
                    level = state.gpio[pin]
                return self._send(200, {"ok": True, "pin": pin, "level": level})

            if route == "/pwm_get":
                pin = self._check_pin(qint("pin"))
                if pin is None:
                    return self._bad_request(f"pin 必须是 {GPIO_MIN}-{GPIO_MAX} 的整数")
                with state.lock:
                    duty = state.pwm.get(pin, 0)
                return self._send(200, {"ok": True, "pin": pin, "duty": duty})

            if route == "/adc_read":
                pin = qint("pin")
                if pin != PHOTO_PIN:
                    return self._bad_request(
                        f"引脚 {pin} 不是 ADC 引脚：本板只有光敏电阻接在引脚 {PHOTO_PIN}"
                    )
                with state.lock:
                    raw = state.adc_raw()
                voltage = round(raw / ADC_MAX * VREF, 3)
                return self._send(
                    200, {"ok": True, "pin": PHOTO_PIN, "raw": raw, "voltage": voltage}
                )

            if route == "/state":
                with state.lock:
                    snap = {
                        "ok": True,
                        "led_pin": LED_PIN,
                        "led_brightness": state.led_brightness(),
                        "photo_pin": PHOTO_PIN,
                        "pwm": dict(state.pwm),
                        "firmware": state.firmware,
                        "uptime_s": round(time.time() - state.boot_time, 1),
                    }
                return self._send(200, snap)

            if route == "/logs":
                limit = qint("limit") or 20
                limit = max(1, min(limit, LOG_CAPACITY))
                with state.lock:
                    entries = list(state.logs)[-limit:]
                return self._send(200, {"ok": True, "count": len(entries), "logs": entries})

            if route == "/":
                return self._send(
                    200,
                    {
                        "ok": True,
                        "name": "devboard-simulator",
                        "endpoints": [
                            "POST /gpio_write", "GET /gpio_read", "POST /pwm_set",
                            "GET /pwm_get", "GET /adc_read", "GET /state",
                            "GET /logs", "POST /reset", "POST /flash",
                        ],
                    },
                )

            return self._send(404, {"ok": False, "error": f"未知路径 {route}"})

        def do_POST(self):
            route = urlsplit(self.path).path.rstrip("/") or "/"
            data = self._read_json()
            if data is None:
                return

            if route == "/gpio_write":
                pin = self._check_pin(data.get("pin"))
                level = data.get("level")
                if pin is None:
                    return self._bad_request(
                        f"pin 非法: {data.get('pin')!r}（必须是 {GPIO_MIN}-{GPIO_MAX} 的整数）"
                    )
                if level not in (0, 1):
                    return self._bad_request(f"level 非法: {level!r}（只能是 0 或 1）")
                with state.lock:
                    state.gpio[pin] = level
                    if pin in state.pwm:
                        del state.pwm[pin]  # 数字写覆盖 PWM
                    state.log(f"gpio_write: GPIO{pin} -> {level}")
                return self._send(200, {"ok": True, "pin": pin, "level": level})

            if route == "/pwm_set":
                pin = self._check_pin(data.get("pin"))
                duty = data.get("duty")
                if pin is None:
                    return self._bad_request(
                        f"pin 非法: {data.get('pin')!r}（必须是 {GPIO_MIN}-{GPIO_MAX} 的整数）"
                    )
                if not isinstance(duty, int) or isinstance(duty, bool) or not 0 <= duty <= 100:
                    return self._bad_request(f"duty 非法: {duty!r}（必须是 0-100 的整数，单位 %）")
                with state.lock:
                    state.pwm[pin] = duty
                    state.log(f"pwm_set: GPIO{pin} duty={duty}%")
                return self._send(200, {"ok": True, "pin": pin, "duty": duty})

            if route == "/reset":
                with state.lock:
                    state.reset_state()
                return self._send(200, {"ok": True, "message": "开发板已复位"})

            if route == "/flash":
                name = data.get("name")
                code = data.get("code")
                if not isinstance(name, str) or not name:
                    return self._bad_request("name 必须是非空字符串（固件名）")
                if not isinstance(code, str):
                    return self._bad_request("code 必须是字符串（固件源码）")
                with state.lock:
                    state.firmware = name
                    state.log(f"firmware_flash: 已烧录 {name}（{len(code)} 字节）")
                return self._send(200, {"ok": True, "flashed": name})

            return self._send(404, {"ok": False, "error": f"未知路径 {route}"})

    return Handler


def start_in_thread(host: str = "127.0.0.1", port: int = 0):
    """在后台线程启动模拟器（测试用）。返回 (server, thread, base_url)。"""
    server = ThreadingHTTPServer((host, port), _make_handler(BoardState()))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base_url = f"http://{host}:{server.server_address[1]}"
    return server, thread, base_url


def run_server(host: str = "127.0.0.1", port: int = 8765) -> None:
    """前台启动模拟器（python3 -m simulator serve 入口）。"""
    server = ThreadingHTTPServer((host, port), _make_handler(BoardState()))
    print(f"[devboard-simulator] 已启动: http://{host}:{port}")
    print(f"[devboard-simulator] 板载: LED=GPIO{LED_PIN}, 光敏=ADC{PHOTO_PIN}；Ctrl-C 停止")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[devboard-simulator] 已停止")
        server.server_close()
