"""模拟器 HTTP 客户端（纯 stdlib，urllib 实现）。供 MCP server、测试、固件脚本调用。

地址解析优先级：构造参数 base_url > 环境变量 SIMULATOR_URL > 默认 http://127.0.0.1:8765。
（base_url 在每次请求时动态解析，方便测试切换端口。）

错误约定：任何失败统一抛 BoardError，消息是可读的中文文本
（连不上 / 超时 / HTTP 4xx-5xx / 响应非 JSON），上层负责转成 "ERROR: ..." 返回给模型。
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request

DEFAULT_BASE_URL = "http://127.0.0.1:8765"


class BoardError(RuntimeError):
    """模拟器通信 / 校验错误的统一异常类型。"""


class BoardClient:
    def __init__(self, base_url: str | None = None, timeout: float = 5.0) -> None:
        self._base_url = base_url
        self.timeout = timeout

    @property
    def base_url(self) -> str:
        return self._base_url or os.environ.get("SIMULATOR_URL", DEFAULT_BASE_URL)

    # ---- 底层请求 ----
    def _request(self, method: str, path: str, payload: dict | None = None) -> dict:
        url = self.base_url.rstrip("/") + path
        data = json.dumps(payload).encode("utf-8") if payload is not None else None
        req = urllib.request.Request(
            url, data=data, method=method,
            headers={"Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                body = resp.read().decode("utf-8")
        except urllib.error.HTTPError as e:
            # 4xx/5xx：模拟器返回了 JSON 错误体，尽量抽出 error 字段
            raw = e.read().decode("utf-8", errors="replace")
            try:
                msg = json.loads(raw).get("error", raw)
            except ValueError:
                msg = raw
            raise BoardError(f"模拟器返回 HTTP {e.code}: {msg}") from None
        except TimeoutError:
            raise BoardError(f"请求超时（{self.timeout}s）: {url}") from None
        except urllib.error.URLError as e:
            raise BoardError(
                f"无法连接模拟器 {self.base_url}: {e.reason}。请先运行 make sim 启动模拟器"
            ) from None
        try:
            return json.loads(body)
        except ValueError:
            raise BoardError(f"模拟器响应不是合法 JSON: {body[:200]}") from None

    # ---- 板子 API（与 HTTP 接口一一对应）----
    def gpio_write(self, pin: int, level: int) -> dict:
        return self._request("POST", "/gpio_write", {"pin": pin, "level": level})

    def gpio_read(self, pin: int) -> dict:
        return self._request("GET", f"/gpio_read?pin={pin}")

    def pwm_set(self, pin: int, duty: int) -> dict:
        return self._request("POST", "/pwm_set", {"pin": pin, "duty": duty})

    def pwm_get(self, pin: int) -> dict:
        return self._request("GET", f"/pwm_get?pin={pin}")

    def adc_read(self, pin: int) -> dict:
        return self._request("GET", f"/adc_read?pin={pin}")

    def state(self) -> dict:
        return self._request("GET", "/state")

    def logs(self, limit: int = 20) -> dict:
        return self._request("GET", f"/logs?limit={limit}")

    def reset(self) -> dict:
        return self._request("POST", "/reset", {})

    def flash(self, name: str, code: str) -> dict:
        return self._request("POST", "/flash", {"name": name, "code": code})
