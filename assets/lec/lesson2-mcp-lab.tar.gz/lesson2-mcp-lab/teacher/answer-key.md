# Teacher Answer Key —— 实验二（学生勿看）

## 1. L1 参考实现：`pwm_set`

替换 `mcp_server/server.py` 中 `pwm_set` 的 TODO 桩（保留原 docstring）：

```python
@mcp.tool()
def pwm_set(pin: int, duty: int) -> str:
    """设置 PWM 占空比，用于调节 LED 亮度（或电机转速等模拟量输出）。

    Args:
        pin: 引脚号，整数，范围 0-33（含）。板载 LED 在 GPIO2，对它设置
            PWM 即调光：duty 就是亮度百分比。
        duty: 占空比，整数，范围 0-100，单位 %（0=常灭，50=半亮，100=常亮）。

    Returns:
        成功返回以 "OK" 开头的文本（应包含 pin 与 duty 便于日志核对）；
        参数非法或模拟器不可达时返回以 "ERROR: " 开头的可读文本。
    """
    # ① schema 校验：pin 0-33（排除 bool，因为 bool 是 int 的子类）
    if not isinstance(pin, int) or isinstance(pin, bool) or not 0 <= pin <= 33:
        return f"ERROR: pin 非法（{pin!r}）。必须是 0-33 的整数"
    # ② schema 校验：duty 0-100
    if not isinstance(duty, int) or isinstance(duty, bool) or not 0 <= duty <= 100:
        return f"ERROR: duty 非法（{duty!r}）。必须是 0-100 的整数，单位 %"
    # ③ 错误处理：模拟器不可达 / 返回 4xx 时给可读文本，不抛裸异常
    try:
        board.pwm_set(pin, duty)
    except BoardError as e:
        return f"ERROR: {e}"
    # ④ 成功文本带上 pin 与 duty，便于 agent 做日志核对
    return f"OK: GPIO{pin} PWM 占空比已设为 {duty}%"
```

## 2. L1 参考实现：`adc_read`

```python
@mcp.tool()
def adc_read(pin: int) -> str:
    """读取 ADC 引脚的模拟值（光敏电阻），用于感知环境亮度——闭环的"眼睛"。

    本板只有一个 ADC 引脚：光敏电阻接在引脚 34。物理特性：LED 越亮，
    光敏读数越高（环境光基础值约 800，LED 满亮时约 3000，含 ±40 噪声）。

    Args:
        pin: ADC 引脚号，本板只接受 34（光敏电阻）。

    Returns:
        成功返回以 "OK" 开头的文本，必须同时包含：
        原始值 raw（0-4095，12-bit）与换算电压 voltage（0-3.3V，保留 3 位小数）；
        pin 不是 34 或模拟器不可达时返回以 "ERROR: " 开头的可读文本。
    """
    # ① schema 校验：本板唯一 ADC 引脚是 34
    if pin != PHOTO_PIN:
        return f"ERROR: 引脚 {pin} 不是 ADC 引脚。本板光敏电阻接在引脚 {PHOTO_PIN}"
    # ② 错误处理
    try:
        result = board.adc_read(pin)
    except BoardError as e:
        return f"ERROR: {e}"
    # ③ 成功文本同时给原始值和换算电压（单位、范围写清楚）
    return (
        f"OK: ADC{pin} 原始值 raw = {result['raw']} (0-4095, 12-bit), "
        f"电压 = {result['voltage']} V (0-3.3V)"
    )
```

### 参考实现的评分对照

| 评分点 | pwm_set | adc_read |
|---|---|---|
| schema 校验 10 | pin 0-33 + duty 0-100，排除 bool | pin == 34 |
| 错误处理 5 | try/except BoardError → ERROR 文本 | 同左 |
| docstring 5 | 范围 + 单位 % + LED 引脚提示 | raw 范围 + 电压单位 + 物理特性 |

常见学生错误：
- 用 `assert` 或抛异常做校验（模型收到裸 traceback，扣分）；
- duty 允许浮点/超界（schema 不严，扣分）；
- docstring 没写单位与范围（模型无法自纠，扣分）；
- 忘记 `isinstance(pin, bool)` 排除——`True` 会被当成 1 通过校验（不扣大分，可作讲评点）。

## 3. `firmware/light_led.py` 的 2 个 bug 与修复

### Bug①：引脚号写错

```python
LED_PIN = 15          # ✗ 错：板上没有接 LED，写"成功"但灯不亮
LED_PIN = 2           # ✓ 对：板载 LED 在 GPIO2（见 firmware/pins.md）
```

症状：脚本不报错，但 `/state` 里 `led_brightness` 恒为 0——**只有读回验证能发现**。
（若 Bug② 先被修复，读回比对分支会打印"验证失败：期望亮度 64%，实际 0%"。）

### Bug②：类型错误

```python
TARGET_DUTY = "80"    # ✗ 错：字符串
duty = TARGET_DUTY * DIM_FACTOR   # TypeError: can't multiply sequence by non-int of type 'float'

TARGET_DUTY = 80      # ✓ 对：int
```

症状：运行即 traceback。`ruff check` 查不出来（不是风格问题），要靠运行/测试暴露——
可用来讲「静态检查通过 ≠ 能 work」。

### 修复后预期输出

```
验证通过：LED(GPIO2) 亮度 = 64%
```

## 4. L2 参考：skill 验证段的固件版写法（讲评用）

```markdown
3. 验（硬件在环）：
   - 烧录：firmware_flash(firmware/light_led.py, confirm=true)【先向用户确认】
   - 成功标准（机器可判）：
     a. gpio_read(2) 返回文本以 "OK" 开头且电平 = 1；
     b. adc_read(34) 原始值 ∈ [1800, 2400]（LED 约 64% 亮度时的耦合读数区间）；
     c. get_logs(10) 中包含本次 pwm_set/flash 事件。
   - 任一不满足 → 回到第 1 步，最多 3 轮，超限停止并报告最后一次错误文本。
```

注意讲评点：skill 里**只引用 tool 名字 + 判定标准**，不复述参数细节（细节归 docstring，
双份复制会漂移——第 3 节课反模式）。
