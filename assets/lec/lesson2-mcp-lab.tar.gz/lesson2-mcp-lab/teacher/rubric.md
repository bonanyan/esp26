# 实验二评分 Rubric（总分 100）

> 原则：所有得分点尽量用**机器可判**证据（make check 输出、curl /state、agent 会话记录）。

## L0 注册并点灯（20 分）

| 项 | 分值 | 判定证据 |
|---|---|---|
| `make setup` + `make doctor` 通过 | 4 | doctor 输出全 ✓ |
| MCP server 在 agent CLI 注册成功 | 6 | agent 能列出 7 个 devboard tools |
| agent 调用 `gpio_write(2,1)` 点灯 | 6 | 会话记录中有该 tool call |
| 读回确认（agent 或人工 curl） | 4 | `curl /state` 中 `led_brightness` > 0 |

## L1 补全两个 tool（40 分，每个 tool 20 分）

### 每个 tool（pwm_set / adc_read 各一套）

| 项 | 分值 | 判定标准 |
|---|---|---|
| schema 校验 | 10 | 非法参数（越界 pin / duty、非 34 引脚、bool 混入）返回 `ERROR: ...` 文本而非异常或"成功"；对应 pytest 用例通过 |
| 错误处理 | 5 | `try/except BoardError`；模拟器不可达时返回可读 ERROR 文本（可现场 `make stop` 后调用验证）；不抛裸 traceback |
| docstring | 5 | 参数含义 + 范围 + 单位齐全（duty %、raw 0-4095、电压 0-3.3V）；`list_tools` 里 description 可读出用途 |

### 一键判定

```bash
make check   # 全绿 = L1 基本盘拿到（30 分）；其余 10 分按上面两项人工核 docstring 与错误文本质量
```

## L2 综合：skill × MCP 端到端（40 分）

| 项 | 分值 | 判定标准 |
|---|---|---|
| skill 改造为固件版 | 10 | 验证段引用 flash + HIL 读回（只写 tool 名 + 判定标准，不复述参数细节） |
| 修复 firmware 两个 bug | 8 | 引脚号改对（2）+ 类型错误改对（80 为 int）；`python3 firmware/light_led.py` 打印"验证通过" |
| agent 端到端跑通 | 12 | 会话记录呈现 写→查→验 闭环；最终 `curl /state` 的 `led_brightness` 与固件设定一致 |
| 成功标准机器可判 | 5 | skill/会话中的判定是数值区间或 OK 前缀，不是"看起来亮了" |
| 加分：感光调光 | 5 | adc 读数低→调高亮度、高→调低，且用读数区间自动判定（封顶 100） |

## 评分操作建议

- 先跑 `make check` 定 L1 基本盘，再看 agent 会话记录定 L0/L2；
- 学生改测试凑通过：L1 清零（第 1 节课负面清单的延续，开场就声明）；
- 未完成 L2 的课后补交：会话记录 + `curl /state` 截图为准。
