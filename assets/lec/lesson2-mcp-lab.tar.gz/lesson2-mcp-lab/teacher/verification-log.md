# 实验二脚手架自验记录（verification-log）

- 验证日期：2026-10-13
- 环境：macOS (darwin) / Python 3.13.11 / venv `.venv`
- 结论：**脚手架可用**。学生初始状态 `make check` = 18 passed / 8 failed（失败全部为
  pwm/adc 两个 TODO 桩，符合预期）；套用 teacher/answer-key.md 参考实现后 **26 passed 全绿**。

## 1. make setup / make doctor

```
$ make setup
python3 -m venv .venv
.venv/bin/pip install -q -r requirements.txt
✓ 依赖安装完成

$ make doctor
✓ Python: Python 3.13.11
✓ mcp 已安装
✓ pytest 已安装
⚠ 模拟器未启动（做 L0 前运行 make sim；make check 不需要）
doctor 完成
```

> ⚠️ 踩坑记录（已修复）：`pip install mcp` 默认装到 **mcp 2.x**，其中
> `mcp.server.fastmcp` 已被移除（FastMCP 改名 MCPServer），导致 import 失败。
> 已将 requirements.txt 钉为 `mcp>=1.2.0,<2`（实测安装 mcp 1.30.0）。
> **无需 mcp_stub shim**：网络正常时 pip 安装成功。

## 2. make sim + curl 冒烟（含 ADC-LED 物理耦合）

```
$ make sim
✓ 模拟器已启动 (http://127.0.0.1:8765, pid 20045)

$ curl http://127.0.0.1:8765/state
{"ok": true, "led_pin": 2, "led_brightness": 0, "photo_pin": 34, "pwm": {}, "firmware": null, "uptime_s": 0.3}

$ curl -X POST http://127.0.0.1:8765/gpio_write -d '{"pin":2,"level":1}'
{"ok": true, "pin": 2, "level": 1}

$ curl "http://127.0.0.1:8765/adc_read?pin=34"      # LED 点亮后读数升高（耦合生效）
{"ok": true, "pin": 34, "raw": 3030, "voltage": 2.442}

$ curl "http://127.0.0.1:8765/logs?limit=5"
{"ok": true, "count": 2, "logs": [{"t": ..., "event": "board reset: GPIO/PWM/固件已清空"},
                                   {"t": ..., "event": "gpio_write: GPIO2 -> 1"}]}
```

## 3. make check —— 学生初始状态（TODO 桩，预期部分失败）

```
$ make check
FAILED tests/test_hil.py::TestPwmLedBrightness::test_pwm_set_changes_led_brightness
FAILED tests/test_hil.py::TestAdcPhysics::test_adc_dark_baseline
FAILED tests/test_hil.py::TestAdcPhysics::test_adc_couples_with_led_brightness
FAILED tests/test_mcp_tools.py::TestPwmStudent::test_pwm_set_ok
FAILED tests/test_mcp_tools.py::TestPwmStudent::test_pwm_set_duty_out_of_range
FAILED tests/test_mcp_tools.py::TestPwmStudent::test_pwm_set_bad_pin
FAILED tests/test_mcp_tools.py::TestAdcStudent::test_adc_read_ok_contains_raw_and_voltage
FAILED tests/test_mcp_tools.py::TestAdcStudent::test_adc_read_rejects_non_adc_pin
========================= 8 failed, 18 passed in 0.69s =========================
```

✅ gpio_write/gpio_read/reset/logs/flash/错误处理等 18 个用例全过；
✅ 8 个失败全部指向 pwm_set / adc_read 两个 TODO 桩（返回 NOT_IMPLEMENTED 文本）。

> 踩坑记录（已修复）：最初 `/reset` 会连日志一起清空，导致
> `test_operations_recorded_in_ring_buffer` 无法验证"复位前的历史仍可查"。
> 已改为**日志环形缓冲跨复位保留**（更贴近真机语义，也利于 agent 诊断）。

## 4. 套用 teacher/answer-key.md 参考实现后

```
$ make check
============================== 26 passed in 0.68s ==============================
```

✅ 全绿。随后已把 `mcp_server/server.py` 还原为学生 TODO 桩版本（本 scaffold 发布态）。

## 5. firmware/light_led.py 埋 bug 验证

```
$ .venv/bin/python firmware/light_led.py          # 原样运行 → Bug② 类型错误先炸
TypeError: can't multiply sequence by non-int of type 'float'

$ # 套用 answer-key 修复（LED_PIN 15→2，TARGET_DUTY "80"→80）后：
验证通过：LED(GPIO2) 亮度 = 64%

$ curl http://127.0.0.1:8765/state
{"ok": true, "led_pin": 2, "led_brightness": 64, "pwm": {"2": 64}, ...}
```

✅ 两个 bug（引脚号 + 类型错误）症状与修复路径均符合讲义描述；
Bug②（TypeError）先于 Bug①（引脚错）暴露，学生修完一个才会撞上第二个——分层递进符合设计。

## 6. MCP server 注册冒烟（tools 列表 + 危险操作标注）

```
$ .venv/bin/python -c "... asyncio.run(srv.mcp.list_tools()) ..."
已注册 tools: ['gpio_write', 'gpio_read', 'board_reset', 'get_logs', 'firmware_flash', 'pwm_set', 'adc_read']
firmware_flash annotations: title='烧录固件（危险操作，不可逆，需用户确认）' destructiveHint=True idempotentHint=False openWorldHint=False
```

✅ 7 个 tool 全部注册；firmware_flash 的 destructive 标注生效，且未确认时拒绝执行
（test_flash_requires_confirmation 通过）。

## 7. make stop

```
$ make stop
✓ 已停止 (pid 20045)
```

## 8. 追加：make lint 与发布态复核（同日稍后）

- 新增 `ruff.toml`（select E/F/W/RUF，ignore RUF001-003——中文标点会触发数百条
  ambiguous-unicode 噪声；行长 100）；
- 移除全部多余 `# noqa: E402 / N802`（实测当前 ruff 版本对 `sys.path.insert` 之后的
  import 不报 E402，noqa 反而触发 RUF100）；
- 复核结果：`make lint` → All checks passed!；`make check`（学生桩发布态）→
  **8 failed / 18 passed**（失败仍全部为 pwm/adc TODO 桩，与第 3 节一致）；
  已清理 .sim.log / __pycache__ / .pytest_cache / .ruff_cache（`.venv` 保留，教室可离线复跑）。
