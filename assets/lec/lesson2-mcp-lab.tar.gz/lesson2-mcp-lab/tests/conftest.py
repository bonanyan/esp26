"""pytest 公共夹具：在测试进程内拉起模拟器（随机空闲端口），全程无需外部 make sim。

- 若环境中已设置 SIMULATOR_URL 且指向可用服务，也可以直接复用它（HIL 真机模式）；
  默认行为是自建进程内模拟器，保证 make check 开箱即跑。
- 每个测试前自动 board_reset，保证用例之间互不污染。
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

# 让 tests/ 里能 import simulator 与 mcp_server
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


@pytest.fixture(scope="session")
def sim_url():
    """会话级：启动进程内模拟器并把 SIMULATOR_URL 指向它。"""
    from simulator.board import start_in_thread

    server, _thread, base_url = start_in_thread(port=0)
    old = os.environ.get("SIMULATOR_URL")
    os.environ["SIMULATOR_URL"] = base_url
    yield base_url
    server.shutdown()
    if old is None:
        os.environ.pop("SIMULATOR_URL", None)
    else:
        os.environ["SIMULATOR_URL"] = old


@pytest.fixture(autouse=True)
def fresh_board(sim_url):
    """每个测试前复位板子，保证状态干净。"""
    from simulator.client import BoardClient

    BoardClient().reset()
    return sim_url
