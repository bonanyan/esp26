"""HIL（硬件在环）测试：不测函数返回值，而是查模拟器的真实板载状态。

与 test_mcp_tools.py 的区别：这里通过 simulator.client 直接读板子的
/state、/adc_read，验证"物理效果"真的发生了——这是第 3 节课反复强调的
「机器可判的真实反馈」。

⚠️ 依赖 L1 完成的 pwm_set / adc_read tool：完成前部分用例预期失败。
"""
from __future__ import annotations

from mcp_server import server as srv
from simulator.client import BoardClient

board = BoardClient()  # 地址来自 conftest 设置的 SIMULATOR_URL


class TestWriteReadback:
    def test_gpio_write_then_read_back(self):
        """写后读回：电平必须与写入值一致（闭环最小单元）。"""
        assert srv.gpio_write(4, 1).startswith("OK")
        assert srv.gpio_read(4).rstrip().endswith("= 1")
        assert srv.gpio_write(4, 0).startswith("OK")
        assert srv.gpio_read(4).rstrip().endswith("= 0")

    def test_write_is_visible_in_board_state(self):
        srv.gpio_write(4, 1)
        # 绕过 MCP，直接问板子：引脚状态确实变了
        assert board.gpio_read(4)["level"] == 1


class TestPwmLedBrightness:
    def test_pwm_set_changes_led_brightness(self):
        """pwm_set(2, 75) 后，板子 /state 里 LED 亮度应约等于 75%。"""
        result = srv.pwm_set(2, 75)
        assert result.startswith("OK"), f"pwm_set 未实现或失败: {result}"
        brightness = board.state()["led_brightness"]
        assert brightness == 75

    def test_pwm_zero_turns_led_off(self):
        srv.pwm_set(2, 100)
        srv.pwm_set(2, 0)
        assert board.state()["led_brightness"] == 0


class TestAdcPhysics:
    def test_adc_dark_baseline(self):
        """LED 全灭时，光敏读数应在环境光基础值附近（800±100）。"""
        result = srv.adc_read(34)
        assert result.startswith("OK"), f"adc_read 未实现或失败: {result}"
        raw = board.adc_read(34)["raw"]
        assert 700 <= raw <= 900

    def test_adc_couples_with_led_brightness(self):
        """物理耦合验证：LED 越亮光敏读数越高（真实反馈，不是摆设）。"""
        srv.pwm_set(2, 0)
        dark = board.adc_read(34)["raw"]
        srv.pwm_set(2, 100)
        bright = board.adc_read(34)["raw"]
        assert bright - dark > 1500, f"耦合异常: dark={dark}, bright={bright}"

    def test_adc_voltage_conversion(self):
        """电压换算应在 0-3.3V 合法区间。"""
        srv.adc_read(34)
        resp = board.adc_read(34)
        assert 0.0 <= resp["voltage"] <= 3.3


class TestLogsHIL:
    def test_operations_recorded_in_ring_buffer(self):
        srv.gpio_write(4, 1)
        srv.board_reset()
        logs = board.logs(50)["logs"]
        events = " | ".join(e["event"] for e in logs)
        assert "gpio_write: GPIO4 -> 1" in events
        assert "board reset" in events
