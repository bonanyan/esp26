"""MCP tool 单元测试：直接调用 tool 函数（不起 agent、不走 stdio），断言返回文本约定。

约定回顾：
- 成功 → 以 "OK" 开头的可读文本；
- 失败 → 以 "ERROR" 开头的可读文本（绝不抛裸异常、绝不返回 NOT_IMPLEMENTED）。

⚠️ 学生注意：TestPwmStudent / TestAdcStudent 两个类在 L1 完成前【预期失败】
（当前桩返回 NOT_IMPLEMENTED）。make check 后其它用例应全绿。
"""
from __future__ import annotations

from mcp_server import server as srv


class TestGpioTools:
    def test_gpio_write_ok(self):
        assert srv.gpio_write(4, 1).startswith("OK")

    def test_gpio_write_pin_out_of_range(self):
        result = srv.gpio_write(99, 1)
        assert result.startswith("ERROR")

    def test_gpio_write_pin_negative(self):
        assert srv.gpio_write(-1, 0).startswith("ERROR")

    def test_gpio_write_bad_level(self):
        assert srv.gpio_write(2, 5).startswith("ERROR")

    def test_gpio_read_ok(self):
        srv.gpio_write(4, 1)
        result = srv.gpio_read(4)
        assert result.startswith("OK")
        assert "1" in result

    def test_gpio_read_bad_pin(self):
        assert srv.gpio_read(34).startswith("ERROR")


class TestResetAndLogs:
    def test_board_reset_ok(self):
        srv.gpio_write(2, 1)
        assert srv.board_reset().startswith("OK")
        assert "= 0" in srv.gpio_read(2)  # 复位后电平清零

    def test_get_logs_records_operations(self):
        srv.gpio_write(2, 1)
        logs = srv.get_logs(10)
        assert logs.startswith("OK")
        assert "gpio_write" in logs and "GPIO2" in logs

    def test_get_logs_bad_limit(self):
        assert srv.get_logs(0).startswith("ERROR")


class TestFirmwareFlash:
    def test_flash_requires_confirmation(self):
        """危险操作：未确认必须拒绝执行，且提示里说明确认方式。"""
        result = srv.firmware_flash("firmware/light_led.py", confirm=False)
        assert result.startswith("ERROR")
        assert "确认" in result

    def test_flash_missing_file(self):
        result = srv.firmware_flash("firmware/not_exist.py", confirm=True)
        assert result.startswith("ERROR")

    def test_flash_ok_with_confirm(self):
        result = srv.firmware_flash("firmware/light_led.py", confirm=True)
        assert result.startswith("OK")
        assert "light_led.py" in result


class TestErrorHandlingWhenSimDown:
    def test_tool_returns_error_text_not_exception(self, monkeypatch):
        """模拟器不可达时，tool 必须返回可读 ERROR 文本而不是抛异常。"""
        monkeypatch.setenv("SIMULATOR_URL", "http://127.0.0.1:1")  # 必连不上的端口
        result = srv.gpio_write(2, 1)
        assert result.startswith("ERROR")
        assert "模拟器" in result


class TestPwmStudent:
    """L1 任务①：补全 srv.pwm_set 后，本类应从失败变为通过。"""

    def test_pwm_set_ok(self):
        result = srv.pwm_set(2, 50)
        assert result.startswith("OK"), f"pwm_set 未实现或失败: {result}"
        assert "50" in result

    def test_pwm_set_duty_out_of_range(self):
        assert srv.pwm_set(2, 150).startswith("ERROR")
        assert srv.pwm_set(2, -1).startswith("ERROR")

    def test_pwm_set_bad_pin(self):
        assert srv.pwm_set(99, 50).startswith("ERROR")


class TestAdcStudent:
    """L1 任务②：补全 srv.adc_read 后，本类应从失败变为通过。"""

    def test_adc_read_ok_contains_raw_and_voltage(self):
        result = srv.adc_read(34)
        assert result.startswith("OK"), f"adc_read 未实现或失败: {result}"
        # docstring 承诺：同时返回原始值与换算电压
        assert ("raw" in result or "原始值" in result)
        assert ("V" in result or "电压" in result)

    def test_adc_read_rejects_non_adc_pin(self):
        assert srv.adc_read(2).startswith("ERROR")
