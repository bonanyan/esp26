# 实验三：Skill × MCP 协同 + 故障注入

> 第 3 节课实验脚手架。核心命题："保证它能 work" 的终极检验——
> **换一个不知道内情的人能复现闭环**（跨组验收）+ **逆风局行为可预期**（混沌测试）。

## 来源声明（复用材料）

- `simulator/` **复制自 `lessons/lesson2-mcp-lab/simulator/`**（纯 stdlib 开发板模拟器），
  在其基础上新增**混沌开关**：环境变量 `CHAOS=pin_stuck|serial_timeout|adc_drift`；
- `mcp_server/` 复制自 lesson2 的**毕业版**（第 2 节课两个 TODO 已按参考实现补全）。
  上课时建议替换成你自己第 2 节课补全的版本；
- 默认端口 **8766**（与 lesson2 的 8765 错开，两套实验可同时运行）。

## 目录结构

```
lesson3-synergy-lab/
├── simulator/            # 开发板模拟器（lesson2 复制 + 混沌开关）
├── mcp_server/server.py  # devboard MCP server（毕业版，7 个 tools）
├── skills/firmware-synergy/
│   ├── SKILL.md          # 融合版 skill 半成品：3 个 TODO(student) 空位（L1 任务）
│   └── references/pins.md  # 引脚约定 + 光敏物理特性（判定区间的推导依据）
├── runner/synergy_runner.py  # skill 流程的"机器代理"：3 个 TODO 与 SKILL.md 一一对应
├── transcripts/          # 3 份 pre-generated agent 运行记录（L0 分析材料）
│   ├── skill-only.md     #   软件全绿但真板不亮：闭环断在"看不见硬件"
│   ├── mcp-only.md       #   有手无纪律：没读回就宣布成功 + 47 轮无限重试
│   └── synergy.md        #   协同：编排 + 读回比对 + 日志佐证，1 轮通过
├── worksheets/transcript-analysis.md  # L0 分析工作单
├── firmware/light_led.py # 已修复的点灯脚本（flash 演示对象）
├── tests/
│   ├── test_simulator_chaos.py  # 混沌开关自检（发放时全绿）
│   ├── test_skill_structure.py  # SKILL.md 结构自检（补全前后都应全绿）
│   └── test_chaos_hil.py        # 三场景 HIL 验收（带轮次上限；补全前预期失败）
├── teacher/              # answer-key / rubric / verification-log（学生勿看）
├── Makefile              # setup / doctor / sim / chaos-* / check / stop
└── requirements.txt      # mcp(<2)、pytest、ruff
```

## 0. 环境准备

```bash
make setup && make doctor
```

## L0（人人必做，约 5 分钟）：Transcript 分析

**不依赖环境，装环境翻车也能拿分——先做这个。**

1. 依次阅读 `transcripts/skill-only.md` → `mcp-only.md` → `synergy.md`；
2. 完成 `worksheets/transcript-analysis.md`：每份 transcript 的
   **闭环断在哪一步 / 为什么 / 缺了协同五模式中哪一条**，外加 5 道快问快答；
3. 先自己填，再对照各 transcript 文末的「讲义备注」。

✅ 验收：工作单提交（15 分，评分细则见 `teacher/rubric.md`）。

## L1（必做，约 7 分钟）：协同改造

把 `skills/firmware-synergy/SKILL.md` 的 **3 个 TODO(student) 空位**补全
（每个空位内有提示注释；提示看完就删）：

1. **TODO①** 验证段的读回比对步骤：写后用哪个 tool 读回、比对什么值、
   成功标准写成机器可判的数值区间（区间必须能从 `references/pins.md` 的物理特性推导）；
2. **TODO②** 故障诊断分支：把「tool 错误文本 → 处置动作」写成可执行的分支表
   （至少覆盖：504 超时 / 读回不一致 / 传感器漂移 / 未知错误）；
3. **TODO③** 停止条件与升级阈值：轮次上限、什么情况下禁止重试直接升级、
   升级报告必须包含什么。

然后把 skill 翻译成代码：补全 `runner/synergy_runner.py` 的同名 3 个 TODO
（runner 是 skill 的"机器代理"——**skill 里写不清楚的流程，代码里一定写不出来**，
这是自查 skill 质量的最好方法）。

✅ 验收（机器可判）：

```bash
make check    # tests/test_chaos_hil.py 全绿（含无故障基线 + 三故障场景）
```

补全前 `test_chaos_hil.py` 预期失败（NotImplementedError）；
`test_simulator_chaos.py` 与 `test_skill_structure.py` 发放时就应全绿。

## L2（挑战，课上 4 分钟 + 课后）：故障注入 + 跨组验收

### 教师端 / 对手组：开混沌开关

```bash
make chaos-pin-stuck        # gpio_write 返回成功，但读回永远是旧值
make chaos-serial-timeout   # 每个接口 35% 概率随机超时，返回 HTTP 504
make chaos-adc-drift        # ADC 读数整体漂移 +300（LED 物理耦合仍生效）
make stop                   # 验收完毕关闭注入
```

随时确认当前注入状态：`curl http://127.0.0.1:8766/state`（`chaos` 字段）。

三种模式手动验证示例：

```bash
# pin_stuck：写"成功"、读回永远是旧值
make chaos-pin-stuck
curl -s -X POST http://127.0.0.1:8766/gpio_write -d '{"pin":4,"level":1}'   # {"ok": true, ...}
curl -s "http://127.0.0.1:8766/gpio_read?pin=4"                              # level 仍是 0 !

# serial_timeout：多试几次，约 1/3 的请求返回 504
make chaos-serial-timeout
for i in 1 2 3 4 5 6 7 8 9 10; do curl -s -o /dev/null -w "%{http_code}\n" \
  "http://127.0.0.1:8766/gpio_read?pin=2"; done

# adc_drift：LED 全灭时暗态读数从 ~800 漂到 ~1100
make chaos-adc-drift
curl -s "http://127.0.0.1:8766/adc_read?pin=34"
```

### 学生组：接受验收

- 自动化：`make check`（tests/test_chaos_hil.py 就是三场景考官，MAX_ROUNDS=3）；
- 真人 agent 版：注册 MCP 后让 agent 按你的 skill 跑点灯任务，教师/对手组开混沌开关，
  观察 agent 是否**正确诊断恢复**或**按停止条件优雅认输**。

**判分口径（重要）**：recovered 和 escalate **都算对**——逆风局要的不是"必胜"，
是**行为可预期**。死循环硬试、超轮次、灯没亮却宣布成功 → 判不过。

### agent CLI 注册（真人 agent 版用）

MCP server 需要知道模拟器端口（本课默认 8766，通过环境变量传入）：

- **Claude Code**：
  ```bash
  claude mcp add devboard -e SIMULATOR_URL=http://127.0.0.1:8766 -- \
    <实验目录绝对路径>/.venv/bin/python <实验目录绝对路径>/mcp_server/server.py
  ```
- **OpenCode**（opencode.json）：
  ```json
  {
    "mcp": {
      "devboard": {
        "type": "local",
        "command": ["<实验目录绝对路径>/.venv/bin/python", "<实验目录绝对路径>/mcp_server/server.py"],
        "environment": { "SIMULATOR_URL": "http://127.0.0.1:8766" },
        "enabled": true
      }
    }
  }
  ```
- skill 安装：把 `skills/firmware-synergy/` 复制到你的 agent 技能目录
  （如 `.claude/skills/` 或 OpenCode 对应目录），确认 description 触发词能命中任务。

### 跨组验收（20 分）

B 组只按 A 组的 SKILL.md + 本 README 操作（A 组禁止口头指导），三场景行为与 A 组自述
一致才算过；随后 B 组为 A 组现场叠加注入组合故障。详见 `teacher/rubric.md`。

## 常用命令速查

| 命令 | 作用 |
|---|---|
| `make setup` / `make doctor` | 装依赖 / 环境自检 |
| `make sim` | 后台起模拟器（无注入，端口 8766） |
| `make chaos-pin-stuck` | 起模拟器 + 注入 pin_stuck（自动替换旧实例） |
| `make chaos-serial-timeout` | 起模拟器 + 注入 serial_timeout |
| `make chaos-adc-drift` | 起模拟器 + 注入 adc_drift |
| `make stop` | 停模拟器 |
| `make check` | 一键验收（进程内模拟器 + 三场景 HIL，无需先 make sim） |

## 红线

- 不得修改 `tests/` 或 `RunResult` 契约、`MAX_ROUNDS` 来凑通过（一票否决，见 rubric）；
- 混沌模式下模拟器的一切"成功返回"都可能是谎言——这正是本实验要你体会的事。
- 
