"""点灯脚本（已修复版，来自第 2 节课 L2 的参考答案）。

第 2 节课原稿埋了 2 个 bug（LED 引脚号写成 15、TARGET_DUTY 是字符串），
修复后：LED_PIN = 2（见 skills/firmware-synergy/references/pins.md），
TARGET_DUTY = 80（int）。

使用方法（需先启动模拟器）：
    make sim
    python3 firmware/light_led.py

第 3 节课它有两个用途：
1. 作为 firmware_flash 的烧录对象（演示双重护栏：先向用户确认再烧录）；
2. 教师端开混沌开关后重跑，观察"软件看起来没错、硬件行为却不对"的场景。
"""
from __future__ import annotations

import sys
from pathlib import Path

# 允许直接 python3 firmware/light_led.py 运行（把实验根目录加入 import 路径）
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from simulator.client import BoardClient, BoardError

LED_PIN = 2           # 板载 LED（pins.md）
TARGET_DUTY = 80      # 目标亮度（%），int 类型
DIM_FACTOR = 0.8      # 夜间模式降亮系数


def main() -> None:
    board = BoardClient()
    try:
        board.reset()

        # 夜间模式：目标亮度打 8 折
        duty = int(TARGET_DUTY * DIM_FACTOR)

        board.pwm_set(LED_PIN, duty)

        # 写后读回验证：不验证不算完
        state = board.state()
        if state["led_brightness"] == duty:
            print(f"验证通过：LED(GPIO{LED_PIN}) 亮度 = {state['led_brightness']}%")
        else:
            print(f"验证失败：期望亮度 {duty}%，实际 {state['led_brightness']}%")
            sys.exit(2)
    except BoardError as e:
        print(f"板子通信失败: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
