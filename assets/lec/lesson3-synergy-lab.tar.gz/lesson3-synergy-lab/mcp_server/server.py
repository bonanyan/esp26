"""devboard MCP server（FastMCP，stdio 传输）—— 第 3 节课用「毕业版」。

来源声明：复制自 lessons/lesson2-mcp-lab/mcp_server/server.py，其中第 2 节课的两个
TODO(student)（pwm_set / adc_read）已按 teacher/answer-key.md 的参考实现补全。
上课时学生应替换成**自己第 2 节课补全的版本**（或对照自查）。

返回值约定（机器可判）：
- 成功：以 "OK" 开头的可读文本；
- 失败：以 "ERROR: " 开头的可读文本（含原因与建议动作），绝不向模型抛裸异常。
  混沌模式 serial_timeout 下会随机出现 "ERROR: 模拟器返回 HTTP 504: gateway
  timeout..." —— skill 的诊断分支必须能处置它。

注册到 agent CLI 见 README.md。手动验证：python3 mcp_server/server.py（stdio 等待输入）。
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

# 保证无论从哪个目录启动（agent CLI 常用绝对路径直接跑本文件），都能 import simulator 包
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mcp.server.fastmcp import FastMCP

from simulator.client import BoardClient, BoardError

mcp = FastMCP("devboard")
board = BoardClient()  # 地址取自环境变量 SIMULATOR_URL（默认 http://127.0.0.1:8766）

# 板载硬件常量（与 simulator/board.py、firmware/pins.md 一致）
LED_PIN = 2       # 板载 LED 所在 GPIO
PHOTO_PIN = 34    # 光敏电阻所在 ADC 引脚


# ---------------------------------------------------------------------------
# 已实现的 tools（L1 时请对照这里的写法：参数校验 → 调用 → OK/ERROR 文本）
# ---------------------------------------------------------------------------

@mcp.tool()
def gpio_write(pin: int, level: int) -> str:
    """设置 GPIO 引脚电平（写操作，立即生效）。

    Args:
        pin: 引脚号，整数，范围 0-33（含）。板载 LED 在 GPIO2。
        level: 目标电平，只能是 0（低电平/灭）或 1（高电平/亮）。

    Returns:
        成功返回以 "OK" 开头的文本；参数非法或模拟器不可达时返回以
        "ERROR: " 开头的可读文本（含原因与建议动作）。
    """
    if not isinstance(pin, int) or isinstance(pin, bool) or not 0 <= pin <= 33:
        return f"ERROR: pin 非法（{pin!r}）。必须是 0-33 的整数，请对照 references/pins.md"
    if level not in (0, 1):
        return f"ERROR: level 非法（{level!r}）。只能是 0 或 1"
    try:
        board.gpio_write(pin, level)
    except BoardError as e:
        return f"ERROR: {e}"
    return f"OK: GPIO{pin} 已置为电平 {level}"


@mcp.tool()
def gpio_read(pin: int) -> str:
    """读取 GPIO 引脚当前电平（读操作，无副作用）。写后读回验证是闭环的关键步骤。

    Args:
        pin: 引脚号，整数，范围 0-33（含）。

    Returns:
        成功返回形如 "OK: GPIO4 当前电平 = 1" 的文本；失败返回 "ERROR: ..."。
    """
    if not isinstance(pin, int) or isinstance(pin, bool) or not 0 <= pin <= 33:
        return f"ERROR: pin 非法（{pin!r}）。必须是 0-33 的整数"
    try:
        result = board.gpio_read(pin)
    except BoardError as e:
        return f"ERROR: {e}"
    return f"OK: GPIO{pin} 当前电平 = {result['level']}"


@mcp.tool()
def board_reset() -> str:
    """复位开发板：清空全部 GPIO 电平、PWM 输出与已烧录固件（可逆操作，安全）。

    用途：板子状态混乱、读回与预期不符时，先复位再重试一次。

    Returns:
        成功返回 "OK: 开发板已复位..."；失败返回 "ERROR: ..."。
    """
    try:
        board.reset()
    except BoardError as e:
        return f"ERROR: {e}"
    return "OK: 开发板已复位（GPIO/PWM/固件已清空）"


@mcp.tool()
def get_logs(limit: int = 20) -> str:
    """读取开发板事件日志（环形缓冲，最多保留最近 200 条）。

    agent 靠这个工具"看见"板子上发生过什么：每次 gpio_write / pwm_set /
    flash / reset 以及被拒绝的非法请求都会记录在案，是故障诊断的第一手证据。

    Args:
        limit: 返回最近多少条日志，整数 1-200，默认 20。

    Returns:
        成功返回以 "OK: 最近 N 条日志" 开头的多行文本（每行一条，含时间戳）；
        无日志时返回 "OK: 日志为空"；失败返回 "ERROR: ..."。
    """
    if not isinstance(limit, int) or isinstance(limit, bool) or not 1 <= limit <= 200:
        return f"ERROR: limit 非法（{limit!r}）。必须是 1-200 的整数"
    try:
        result = board.logs(limit)
    except BoardError as e:
        return f"ERROR: {e}"
    entries = result["logs"]
    if not entries:
        return "OK: 日志为空（板子刚复位或还没有任何操作）"
    lines = [
        f"[{time.strftime('%H:%M:%S', time.localtime(e['t']))}] {e['event']}"
        for e in entries
    ]
    return f"OK: 最近 {len(entries)} 条日志（旧→新）:\n" + "\n".join(lines)


@mcp.tool(
    annotations={
        "title": "烧录固件（危险操作，不可逆，需用户确认）",
        "destructiveHint": True,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
def firmware_flash(firmware_path: str, confirm: bool = False) -> str:
    """【危险操作】把固件脚本烧录到开发板。会覆盖板上现有固件，不可逆。

    安全约定：必须先向用户展示将要烧录的文件路径并获得明确同意，
    然后才能带 confirm=true 重新调用本工具；confirm=false 时一律拒绝执行。

    Args:
        firmware_path: 固件脚本路径（相对实验目录或绝对路径），如 firmware/light_led.py。
        confirm: 用户确认标记。未确认（false）时本工具拒绝烧录并返回提示。

    Returns:
        成功返回 "OK: 已烧录固件 ..."；未确认 / 文件不存在 / 通信失败返回 "ERROR: ..."。
    """
    if not confirm:
        return (
            "ERROR: firmware_flash 是危险且不可逆的操作，需要用户明确确认。"
            "请先向用户说明将烧录的文件与影响，获得同意后带 confirm=true 重新调用。"
        )
    path = Path(firmware_path)
    if not path.is_absolute():
        # 相对路径按实验根目录解析
        path = Path(__file__).resolve().parents[1] / firmware_path
    if not path.is_file():
        return f"ERROR: 固件文件不存在: {path}"
    try:
        code = path.read_text(encoding="utf-8")
        board.flash(path.name, code)
    except BoardError as e:
        return f"ERROR: {e}"
    except OSError as e:
        return f"ERROR: 读取固件文件失败: {e}"
    return f"OK: 已烧录固件 {path.name}（{len(code)} 字节）。建议随后用 get_logs 确认烧录事件"


# ---------------------------------------------------------------------------
# pwm_set / adc_read：第 2 节课 L1 的参考实现（毕业版，已补全）。
# 写法要点回顾：先 schema 校验 → try/except BoardError 调 board.* →
# 返回 "OK"/"ERROR" 开头的可读文本。
# ---------------------------------------------------------------------------

@mcp.tool()
def pwm_set(pin: int, duty: int) -> str:
    """设置 PWM 占空比，用于调节 LED 亮度（或电机转速等模拟量输出）。

    Args:
        pin: 引脚号，整数，范围 0-33（含）。板载 LED 在 GPIO2，对它设置
            PWM 即调光：duty 就是亮度百分比。
        duty: 占空比，整数，范围 0-100，单位 %（0=常灭，50=半亮，100=常亮）。

    Returns:
        成功返回以 "OK" 开头的文本（应包含 pin 与 duty 便于日志核对）；
        参数非法或模拟器不可达时返回以 "ERROR: " 开头的可读文本。
    """
    # ① schema 校验：pin 0-33（排除 bool，因为 bool 是 int 的子类）
    if not isinstance(pin, int) or isinstance(pin, bool) or not 0 <= pin <= 33:
        return f"ERROR: pin 非法（{pin!r}）。必须是 0-33 的整数"
    # ② schema 校验：duty 0-100
    if not isinstance(duty, int) or isinstance(duty, bool) or not 0 <= duty <= 100:
        return f"ERROR: duty 非法（{duty!r}）。必须是 0-100 的整数，单位 %"
    # ③ 错误处理：模拟器不可达 / 返回 4xx-5xx 时给可读文本，不抛裸异常
    try:
        board.pwm_set(pin, duty)
    except BoardError as e:
        return f"ERROR: {e}"
    # ④ 成功文本带上 pin 与 duty，便于 agent 做日志核对
    return f"OK: GPIO{pin} PWM 占空比已设为 {duty}%"


@mcp.tool()
def adc_read(pin: int) -> str:
    """读取 ADC 引脚的模拟值（光敏电阻），用于感知环境亮度——闭环的"眼睛"。

    本板只有一个 ADC 引脚：光敏电阻接在引脚 34。物理特性：LED 越亮，
    光敏读数越高（环境光基础值约 800，LED 满亮时约 3000，含 ±40 噪声）。

    Args:
        pin: ADC 引脚号，本板只接受 34（光敏电阻）。

    Returns:
        成功返回以 "OK" 开头的文本，必须同时包含：
        原始值 raw（0-4095，12-bit）与换算电压 voltage（0-3.3V，保留 3 位小数）；
        pin 不是 34 或模拟器不可达时返回以 "ERROR: " 开头的可读文本。
    """
    # ① schema 校验：本板唯一 ADC 引脚是 34
    if pin != PHOTO_PIN:
        return f"ERROR: 引脚 {pin} 不是 ADC 引脚。本板光敏电阻接在引脚 {PHOTO_PIN}"
    # ② 错误处理
    try:
        result = board.adc_read(pin)
    except BoardError as e:
        return f"ERROR: {e}"
    # ③ 成功文本同时给原始值和换算电压（单位、范围写清楚）
    return (
        f"OK: ADC{pin} 原始值 raw = {result['raw']} (0-4095, 12-bit), "
        f"电压 = {result['voltage']} V (0-3.3V)"
    )


def main() -> None:
    """stdio 传输入口：agent CLI 会以子进程方式启动本函数。"""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
