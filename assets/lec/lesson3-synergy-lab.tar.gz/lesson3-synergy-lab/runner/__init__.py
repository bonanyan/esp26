"""runner 包：synergy_runner 是 skill 流程的"机器代理"，供混沌 HIL 验收测试调用。"""
