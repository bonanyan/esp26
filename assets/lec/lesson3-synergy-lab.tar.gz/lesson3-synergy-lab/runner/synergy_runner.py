"""agent 代理 runner —— 把 skills/firmware-synergy/SKILL.md 的流程翻译成确定性代码。

为什么需要它：L2 故障注入验收要求**机器可判**。真实 agent 会话无法自动评分，
所以把 skill 定义的「写→验→诊断→停止」流程固化到本 runner，
tests/test_chaos_hil.py 用它对三种混沌场景（pin_stuck / serial_timeout / adc_drift）
做带轮次上限的验收。

runner 里的 3 个 TODO(student) 与 SKILL.md 的 3 个空位**一一对应**：
    SKILL.md TODO①（读回比对）   ↔ 本文件 TODO①
    SKILL.md TODO②（诊断分支）   ↔ 本文件 TODO②
    SKILL.md TODO③（停止条件）   ↔ 本文件 TODO③
先把 skill 填好，再照着翻译成代码——skill 写不清楚的地方，代码也一定写不出来。

契约（混沌 HIL 验收的判过标准，全部机器可判）：
- run_light_loop(max_rounds) 必须在 max_rounds 轮内终止，不得抛任何异常、不得死循环；
- 返回 RunResult：
    status="recovered" → LED 点亮成功，且读回比对 + 光敏物理验证全部通过；
    status="escalate"  → 按停止条件优雅认输，detail 必须含诊断结论与最后一次错误文本；
- 无故障注入时必须 status="recovered"（sanity 基线）；
- 「正确诊断恢复」与「按停止条件优雅认输」都判过；超轮次 / 抛裸异常 / 死循环判不过。

运行前提：模拟器已启动（make sim 或 make chaos-*），或在 pytest 内由 conftest 自动拉起。
"""
from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path

# 保证无论从哪个目录运行，都能 import mcp_server / simulator
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

# 学生补全 TODO 后将会用到 tools（gpio_write/gpio_read/adc_read/board_reset/get_logs）。
# 补全后请顺手删掉行尾的 "# noqa: F401"（届时 tools 已被使用，noqa 反而会被 RUF100 报告）
from mcp_server import server as tools  # noqa: F401  与 agent 调用的是同一套 MCP tool 实现

# ---- 任务常量（与 references/pins.md 的物理特性对应）----
LED_PIN = 2
PHOTO_PIN = 34
TARGET_LEVEL = 1              # 目标：点亮 LED（数字电平拉高）
# 机器可判成功标准：LED 满亮时光敏 raw ≈ 800 + 2200 = 3000，含 ±40 噪声，留出余量：
ADC_EXPECTED_RANGE = (2900, 3100)


@dataclass
class RunResult:
    """一次闭环运行的结果（供 tests/test_chaos_hil.py 断言）。"""

    status: str                 # "recovered" | "escalate"
    rounds: int                 # 实际消耗轮次（一次 写→验 = 1 轮）
    detail: str                 # 人类可读的诊断结论 / 最后一次错误文本
    evidence: list[str] = field(default_factory=list)  # 过程证据：关键 tool 返回文本


def run_light_loop(max_rounds: int = 3) -> RunResult:
    """点亮 LED 并完成硬件在环验证；故障时按诊断分支处置，超限优雅认输。

    每轮流程（对应 SKILL.md 第 3-5 节）：
        gpio_write 写 → gpio_read 读回比对 → adc_read 物理验证 →（失败）诊断分支
    """
    # TODO(student)①：读回比对（对应 SKILL.md 第 3 节空位）——
    #   调用 tools.gpio_write(LED_PIN, TARGET_LEVEL) 后必须读回：
    #   a) 返回文本以 "OK" 开头；
    #   b) tools.gpio_read(LED_PIN) 读回的电平 == 写入值；
    #   c) tools.adc_read(PHOTO_PIN) 解析出 raw，必须 ∈ ADC_EXPECTED_RANGE
    #      （解析提示：文本形如 "OK: ADC34 原始值 raw = 3012 (0-4095, ...)"）。
    #
    # TODO(student)②：故障诊断分支（对应 SKILL.md 第 4 节空位）——
    #   错误文本含 "504"/"timeout"/"超时"      → 瞬时故障：重试（计 1 轮）；
    #   写 OK 但 gpio_read 读回不一致           → tools.board_reset() 后重试一次；
    #     复位后仍不一致                        → 判定"引脚卡死"，升级（别再硬试）；
    #   读回正常但 raw 超出区间上限             → 判定"传感器漂移"，升级（重试无用）；
    #   无法归类的 ERROR                        → 直接走停止条件，不要猜。
    #   （诊断时可调用 tools.get_logs(20) 收集板端证据放进 evidence。）
    #
    # TODO(student)③：停止条件与升级（对应 SKILL.md 第 5 节空位）——
    #   轮次用尽（rounds 达到 max_rounds）或诊断为不可恢复时：
    #   立即停止，返回 RunResult("escalate", 轮次, 诊断结论+最后一次错误文本, 证据)。
    raise NotImplementedError(
        "TODO(student): 请先补全 skills/firmware-synergy/SKILL.md 的 3 个空位，"
        "再把流程翻译成这里的代码。参考实现见 teacher/answer-key.md（教师版，学生先别看）。"
    )
