"""开发板模拟器包（纯 stdlib）。复制自 lesson2-mcp-lab 并新增混沌开关（CHAOS 环境变量）。

- board.py:  内存态板子 + HTTP JSON API + 故障注入（pin_stuck/serial_timeout/adc_drift）
- client.py: 供 MCP server / 测试 / 固件脚本调用的 HTTP 客户端
"""
