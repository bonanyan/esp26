# Teacher Answer Key —— 实验三（学生勿看）

三部分内容：① L0 工作单参考答案；② SKILL.md 三个空位的参考填法；
③ runner/synergy_runner.py 参考实现（用于验证混沌 HIL 测试可全绿）。

---

## ① L0 工作单参考答案

### 任务一：填表

| Transcript | 断点 | 为什么 | 缺失模式 |
|---|---|---|---|
| `skill-only.md` | **验**（第 3 步） | pytest 用 mock 替代真实板子，验证对象是"代码逻辑"不是"硬件状态"；flash、读回、板端日志一个都没发生。agent 想 curl 查板子时发现自己没有任何硬件工具——纪律完好但无手可用 | #1 skill 编排工具（没有工具可编排）、#2 机器可判标准（mock 通过 ≠ 真实反馈） |
| `mcp-only.md` | **验 + 停止条件**（第一轮就断了） | 拿 `gpio_write` 的 "OK" 当成功证据直接宣布完成；被打脸后的"读回"是自证循环——写 GPIO15 读 GPIO15，永远一致、永远无新信息；47 轮重复调用没有轮次上限，也没升级给人。工具全在手（get_logs/adc_read 一次没用），缺的是纪律 | #2 机器可判标准（OK ≠ 灯亮）、#5 失败升级路径（无诊断分支、无阈值、不认输） |
| `synergy.md` | 没断。关键多做的一步：**写后读回比对**——pwm_set 的 OK 不算成功，必须 adc_read 命中**事先从 pins.md 物理特性推导的区间** [2100,2320]，再用 get_logs 佐证操作真实落板 | — | 五条全示范：#1 编排（flash→pwm_set→adc_read→get_logs）、#2 区间判定、#3 flash 双重护栏（先问用户 + confirm 参数）、#4 引脚表放 references、#5 诊断分支备而未发 |

### 任务二：快问快答

1. **mock 测试验证的是"我的代码调用了我想象中的接口"，不是"板子真的亮了"。**
   机器可判 ≠ 判的是真东西；判定对象必须是硬件在环的真实反馈（读回值、光敏读数、板端日志）。
2. **它读回的是自己刚写过的同一个错误引脚（GPIO15）。** 这个读回只能证明"15 号引脚电平是 1"，
   证明不了"LED 亮"——因为 LED 根本不在 15 号引脚上。有效读回必须指向**任务目标的可观测代理**
   （GPIO2 电平 / /state 亮度 / 光敏耦合读数）。
3. 区间来自 pins.md 的物理特性：800 + 2200×0.64 ≈ 2208，±40 噪声 + 量化余量 → [2100, 2320]。
   若写 [0, 4095]，任何读数都"通过"，标准退化为永真式，等于没有验证（和 mcp-only 拿 OK 当成功等价）。
4. 参考句式：**"一次 写→验 = 1 轮，最多 N 轮（建议 ≤3）；超限立即停止重试，
   向用户报告诊断结论 + 最后一次错误文本"**，配合"禁止对同一个失败调用无脑重复"负面清单。
5. synergy 配置。手 = devboard MCP tools（gpio_write/adc_read/get_logs…，`mcp_server/server.py`）；
   纪律 = `skills/firmware-synergy/SKILL.md`（读回比对、诊断分支、停止条件、负面清单）。

### 评分建议（L0 共 15 分）

- 填表 3 行 × 3 分：断点 1 分、证据具体（引用 transcript 内容）1 分、模式指认 1 分；
- 快问快答 5 题 × 2 分（第 5 题计入填表也可，总分封顶 15）；
- 表述与要点吻合即可，不要求逐字。

---

## ② SKILL.md 三个空位的参考填法

### TODO①（第 3 节：读回比对步骤）

```markdown
2. 读回比对（写后必做，缺一步即判失败）：
   a. 数字读回：调用 `gpio_read`（目标引脚），返回文本以 "OK" 开头，
      且读回电平 == 刚写入的值；不一致 → 进入第 4 节诊断分支；
   b. 物理验证：调用 `adc_read`(34) 读光敏原始值 raw。成功标准（机器可判）：
      raw ∈ 期望区间。区间必须**先**由 references/pins.md 的物理特性算出
      （raw ≈ 800 + 2200 × duty%，再留 ±100 噪声/量化余量），禁止拍脑袋写 [0,4095]；
   c. 采样两次，两次都命中区间才算通过（防单次噪声巧合）。
```

### TODO②（第 4 节：故障诊断分支表）

```markdown
| 症状（机器可判） | 诊断 | 处置 |
|---|---|---|
| ERROR 文本含 "504"/"timeout"/"超时" | 串口瞬时故障 | 重试同一操作（计 1 轮）；同一操作连续 2 次超时 → 升级 |
| 写返回 OK 但 gpio_read 读回不一致 | 引脚卡死嫌疑 | `board_reset` 后重试 1 次；仍不一致 → 判"引脚卡死"，升级（复位无效，重试无意义） |
| 读回正常但 adc raw 超出区间**上限** | 传感器漂移 | 禁止重试（漂移不会自愈）；升级：报告读数偏移量，建议人工重新标定 |
| 读回正常但 adc raw 低于区间**下限** | LED 未真实点亮/遮挡 | 检查 duty 与引脚号后重试 1 次；仍低 → 升级 |
| ERROR 无法归类 | 未知故障 | 不猜、不重试，直接走第 5 节升级 |
诊断时可调用 `get_logs`(20) 收集板端证据（被拒绝的请求也会入日志）。
```

### TODO③（第 5 节：停止条件与升级）

```markdown
- 轮次定义：一次"写→验"= 1 轮；总上限 **3 轮**。
- 触发升级（停止一切重试，向用户报告）的条件：
  a. 3 轮用尽仍未通过；
  b. 诊断为不可恢复（引脚卡死复位无效 / 传感器漂移 / 未知错误）；
  c. 危险操作（firmware_flash）未获用户确认。
- 升级报告必须包含：诊断结论 + 最后一次错误文本（原文引用）+ 建议的人工动作
  （查接线 / 换引脚 / 标定传感器）。
- 禁止"再试最后一次"；禁止在升级后继续调用任何写操作工具。
```

---

## ③ runner/synergy_runner.py 参考实现

把 `run_light_loop` 的 `raise NotImplementedError(...)` 及三段 TODO 注释替换为：

```python
def run_light_loop(max_rounds: int = 3) -> RunResult:
    evidence: list[str] = []
    last_error = "尚未执行任何操作"
    rounds = 0
    reset_used = False

    def _is_transient(text: str) -> bool:
        """诊断分支②：错误文本含 504/timeout → 串口瞬时故障。"""
        return any(k in text for k in ("504", "timeout", "超时"))

    while rounds < max_rounds:
        rounds += 1

        # ―― 写 ――
        w = tools.gpio_write(LED_PIN, TARGET_LEVEL)
        evidence.append(f"[第{rounds}轮] 写: {w}")
        if w.startswith("ERROR"):
            last_error = w
            if _is_transient(w):
                continue  # 瞬时故障 → 重试（计轮次）
            return RunResult("escalate", rounds, f"写失败且非瞬时故障，不猜: {w}", evidence)

        # ―― 读回比对（TODO①）――
        g = tools.gpio_read(LED_PIN)
        evidence.append(f"[第{rounds}轮] 读回: {g}")
        if g.startswith("ERROR"):
            last_error = g
            if _is_transient(g):
                continue
            return RunResult("escalate", rounds, f"读回失败: {g}", evidence)
        level = int(g.rsplit("=", 1)[1].strip())
        if level != TARGET_LEVEL:
            # ―― 诊断分支（TODO②）：写 OK 但读回不一致 ――
            last_error = f"写返回成功但读回电平={level}（期望 {TARGET_LEVEL}）"
            logs = tools.get_logs(10)
            evidence.append(f"[第{rounds}轮] 日志佐证: {logs.splitlines()[-1]}")
            if not reset_used:
                reset_used = True
                r = tools.board_reset()
                evidence.append(f"[第{rounds}轮] 复位重试: {r}")
                continue
            return RunResult(
                "escalate", rounds,
                f"诊断: 引脚卡死（写返回成功但读回永远旧值，reset 后仍无效）。"
                f"最后错误: {last_error}。建议人工: 检查接线/更换引脚。", evidence)

        # ―― 物理验证（TODO①）：光敏耦合读数必须命中期望区间 ――
        a = tools.adc_read(PHOTO_PIN)
        evidence.append(f"[第{rounds}轮] 光敏: {a}")
        if a.startswith("ERROR"):
            last_error = a
            if _is_transient(a):
                continue
            return RunResult("escalate", rounds, f"adc_read 持续失败: {a}", evidence)
        raw = int(a.split("raw = ")[1].split(" ", 1)[0])
        lo, hi = ADC_EXPECTED_RANGE
        if lo <= raw <= hi:
            return RunResult(
                "recovered", rounds,
                f"闭环成功: GPIO{LED_PIN} 读回电平={level}，光敏 raw={raw} ∈ [{lo},{hi}]",
                evidence)

        # ―― 诊断分支（TODO②）：数字读回正常但光敏异常 ――
        last_error = f"光敏 raw={raw} 不在期望区间 [{lo},{hi}]"
        if raw > hi:
            return RunResult(
                "escalate", rounds,
                f"诊断: 传感器漂移（LED 数字读回正常，光敏读数整体偏高 +{raw - hi} 以上）。"
                f"重试无用，建议人工重新标定传感器。最后错误: {last_error}", evidence)
        return RunResult(
            "escalate", rounds,
            f"诊断: LED 疑似未真实点亮（光敏读数偏低）但数字读回正常，无法现场确认。"
            f"最后错误: {last_error}", evidence)

    # ―― 停止条件（TODO③）：轮次用尽，优雅认输 ――
    return RunResult(
        "escalate", rounds,
        f"停止条件触发: {max_rounds} 轮尝试后仍未通过，停止重试。最后错误: {last_error}",
        evidence)
```

### 三场景下的预期行为（tests/test_chaos_hil.py 判过依据）

> 套用参考实现时，记得删掉 `runner/synergy_runner.py` 顶部的 `# noqa: F401`
> （届时 `tools` 已被真正使用，保留 noqa 会触发 RUF100）。

| 场景 | 参考实现的行为 | 轮次 | status |
|---|---|---|---|
| 无注入（基线） | 写→读回=1→raw≈3000∈[2900,3100] | 1 | recovered |
| pin_stuck | 写"成功"→读回=0→reset 重试→仍=0→判引脚卡死 | 2 | escalate |
| serial_timeout | 随机 504→按瞬时故障重试；运气差 3 轮全超时→停止条件 | ≤3 | recovered 或 escalate（都判过） |
| adc_drift | 写→读回=1 正常→raw≈3300>3100→判传感器漂移（禁止重试） | 1 | escalate |

评分口径重申：**recovered 与 escalate 都算对**（前提是诊断结论与场景相符、轮次有界）；
灯没亮却报 recovered（假成功）、超轮次、死循环、抛裸异常 → 判不过。
