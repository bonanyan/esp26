# 实验三脚手架自验记录（verification-log）

- 验证日期：2026-10-13
- 环境：macOS (darwin) / Python 3.13.11 / venv `.venv` / mcp 1.30.0（钉 `<2`，同 lesson2）
- 结论：**脚手架可用**。三种 CHAOS 模式 curl 实测行为符合定义；学生初始状态
  `make check` = 12 passed / 5 failed（失败全部为 runner TODO 桩的 NotImplementedError，
  符合预期）；套用 teacher/answer-key.md ③ 的参考实现后 **17 passed 全绿**；
  SKILL.md 半成品含 3 个 TODO(student) 空位，结构完整（tests/test_skill_structure.py 4 项全过）。

## 1. make setup / make doctor

```
$ make setup
✓ 依赖安装完成

$ make doctor
✓ Python: Python 3.13.11
✓ mcp 已安装 (1.x)
✓ pytest 已安装
✓ SKILL.md 就位
⚠ 模拟器未启动（make sim 或 make chaos-*；make check 不需要）
doctor 完成
```

## 2. 三种 CHAOS 模式手动 curl 验证（行为均符合定义）

### pin_stuck：写返回成功，读回永远是旧值 ✅

```
$ make chaos-pin-stuck
✓ 模拟器已启动 (http://127.0.0.1:8766, pid 48720)
  CHAOS='pin_stuck'  /state => {"ok": true, ..., "chaos": "pin_stuck", ...}

$ curl -X POST http://127.0.0.1:8766/gpio_write -d '{"pin":4,"level":1}'
{"ok": true, "pin": 4, "level": 1}          ← 假装成功

$ curl "http://127.0.0.1:8766/gpio_read?pin=4"
{"ok": true, "pin": 4, "level": 0}          ← 读回永远是旧值 0
```

### serial_timeout：随机接口超时返回 504 ✅

```
$ make chaos-serial-timeout
$ for i in $(seq 1 20); do curl -s -o /dev/null -w "%{http_code} " ".../gpio_read?pin=2"; done
504 504 504 200 200 200 200 504 504 200 200 504 200 200 200 200 504 504 504 504
（20 次中 10 次 504，随机、部分成功——重试有意义，符合 35% 概率设计）
```

### adc_drift：读数整体 +300，LED 物理耦合仍生效 ✅

```
$ make chaos-adc-drift
$ curl ".../adc_read?pin=34"                       # LED 全灭（暗态应 ≈800+300=1100）
{"ok": true, "pin": 34, "raw": 1120, "voltage": 0.903}

$ curl -X POST .../gpio_write -d '{"pin":2,"level":1}' && curl ".../adc_read?pin=34"
{"ok": true, "pin": 34, "raw": 3310, "voltage": 2.667}   # ≈3000+300，耦合生效

$ make stop
✓ 已停止 (pid 49132)
```

补充：漂移后的满亮读数 3310 > runner 判定区间上限 3100 → 能被绝对区间判定击穿
（tests/test_simulator_chaos.py::test_drift_breaks_absolute_range_check 覆盖）。

## 3. make check —— 学生初始状态（runner TODO 桩，预期部分失败）

```
$ make check
FAILED tests/test_chaos_hil.py::test_baseline_no_chaos_must_recover - NotImpl...
FAILED tests/test_chaos_hil.py::test_chaos_scenario_bounded_and_diagnosed[pin_stuck]
FAILED tests/test_chaos_hil.py::test_chaos_scenario_bounded_and_diagnosed[serial_timeout]
FAILED tests/test_chaos_hil.py::test_chaos_scenario_bounded_and_diagnosed[adc_drift]
FAILED tests/test_chaos_hil.py::test_pin_stuck_false_recovery_is_caught - Not...
========================= 5 failed, 12 passed in 0.76s =========================
```

✅ 12 个通过 = 混沌开关自检 8 项（test_simulator_chaos.py）+ SKILL.md 结构自检 4 项
（test_skill_structure.py）——脚手架自身质量发放时即全绿；
✅ 5 个失败全部指向 runner/synergy_runner.py 的 `NotImplementedError`（TODO 桩）。

## 4. 套用 answer-key 参考实现后（全绿 + 行为明细）

直接提取 teacher/answer-key.md ③ 的 python 代码块替换桩实现（验证答案可原样抄用）：

```
$ make check
============================== 17 passed in 0.69s ==============================
（test_chaos_hil.py 连跑 3 遍均 5 passed，serial_timeout 随机性下无 flaky）
```

四场景 runner 行为明细（MAX_ROUNDS=3）：

```
CHAOS=(无)             -> status=recovered rounds=1  detail=闭环成功: GPIO2 读回电平=1，光敏 raw=2966 ∈ [2900,3100]
CHAOS=pin_stuck        -> status=escalate  rounds=2  detail=诊断: 引脚卡死（写返回成功但读回永远旧值，reset 后仍无效）...建议人工: 检查接线/更换引脚
CHAOS=serial_timeout   -> status=recovered rounds=2  detail=闭环成功: GPIO2 读回电平=1，光敏 raw=2992 ∈ [2900,3100]（超时轮被正确诊断为瞬时故障并重试）
CHAOS=adc_drift        -> status=escalate  rounds=1  detail=诊断: 传感器漂移（LED 数字读回正常，光敏读数整体偏高 +223 以上）。重试无用，建议人工重新标定传感器
```

✅ 与 answer-key 预期行为对照表完全一致：pin_stuck/adc_drift 正确诊断后**优雅认输**
（escalate），serial_timeout 按瞬时故障有界重试后恢复（recovered），全部轮次 ≤3；
✅ 防假成功断言生效路径已验证（recovered 时直接查板 /state 的 led_brightness）。

随后已将 runner/synergy_runner.py 还原为学生 TODO 桩版本（本 scaffold 发布态），
还原后复测：5 failed / 12 passed（回到第 3 节的预期状态），`make lint` 全过。

## 5. SKILL.md 半成品 TODO 结构检查

```
$ grep -n 'TODO(student)' skills/firmware-synergy/SKILL.md
32:2. **TODO(student)①：读回比对步骤**
43:**TODO(student)②：把「tool 错误文本 → 处置动作」补成一张可执行的分支表**
54:**TODO(student)③：定义轮次上限与升级动作**
```

✅ 3 个空位齐全，各带提示注释（写完即删）；frontmatter 触发词、五个工作流小节、
负面清单由 tests/test_skill_structure.py 4 项断言守护（学生补全后仍须全绿）。

runner 与 SKILL.md 的 TODO 一一对应（①读回比对 / ②诊断分支 / ③停止条件）。

## 6. transcripts 行数（规格 60–100 行/份）

```
skill-only.md   85 行
mcp-only.md    100 行
synergy.md      94 行
```

## 7. 踩坑记录（已修复，供下次备课参考）

- ruff 新版对"中文标点 in docstring"默认报 RUF001/002/003 数百条 → ruff.toml 统一 ignore；
- ruff 不再对 `sys.path.insert` 之后的 import 报 E402 → 移除了全部多余 `# noqa: E402`；
- runner 桩状态下 `tools` import 未使用（F401）→ 保留 `# noqa: F401` 并在注释与
  answer-key 中提醒：学生补全后应删除该 noqa（否则 RUF100）；
- chaos 模式下 `/state` 自身也可能被 serial_timeout 命中 504 → Makefile `_start_sim`
  的就绪探测循环重试 15 次并按响应体判断，避免误报启动失败。
