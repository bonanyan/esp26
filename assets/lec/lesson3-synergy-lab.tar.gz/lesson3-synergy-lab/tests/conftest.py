"""pytest 公共夹具：进程内拉起模拟器（随机端口），每个测试前复位板子。

说明：
- CHAOS 混沌模式由 board.py 在**每次请求时**动态读环境变量，因此测试用
  monkeypatch.setenv("CHAOS", ...) 即可按用例注入故障，无需重启服务；
- fresh_board 是 autouse 且在 chaos 夹具之前执行 → 复位动作本身不受故障注入影响；
  即便如此仍带重试，防 serial_timeout 场景下的偶发 504。
"""
from __future__ import annotations

import os
import sys
import time
from pathlib import Path

import pytest

# 让 tests/ 里能 import simulator / mcp_server / runner
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


@pytest.fixture(scope="session")
def sim_url():
    """会话级：启动进程内模拟器并把 SIMULATOR_URL 指向它。"""
    from simulator.board import start_in_thread

    server, _thread, base_url = start_in_thread(port=0)
    old = os.environ.get("SIMULATOR_URL")
    os.environ["SIMULATOR_URL"] = base_url
    # 确保测试会话开始时没有外部残留的混沌注入
    os.environ.pop("CHAOS", None)
    yield base_url
    server.shutdown()
    if old is None:
        os.environ.pop("SIMULATOR_URL", None)
    else:
        os.environ["SIMULATOR_URL"] = old


@pytest.fixture(autouse=True)
def fresh_board(sim_url):
    """每个测试前复位板子（带重试，容忍 serial_timeout 的随机 504）。"""
    from simulator.client import BoardClient, BoardError

    client = BoardClient()
    for _ in range(12):
        try:
            client.reset()
            break
        except BoardError:
            time.sleep(0.05)
    else:
        pytest.fail("模拟器复位连续失败 12 次——环境异常")
    return sim_url
