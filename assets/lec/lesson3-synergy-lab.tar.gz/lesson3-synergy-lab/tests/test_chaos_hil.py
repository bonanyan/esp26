"""三故障场景 HIL 验收（L2 的机器可判部分）——带轮次上限的闭环测试。

判过标准（与 teacher/rubric.md 一致）：
- runner 在 max_rounds 轮内终止，不抛任何异常、不死循环；
- status ∈ {"recovered", "escalate"} —— 正确诊断恢复、或按停止条件优雅认输，都算过；
- 声称 recovered 时，直接查板子 /state：LED 必须真的亮着（防"假成功"）；
- detail 必须非空（升级时要向人类交代诊断结论与最后一次错误）。

判不过的典型行为：
- 轮次超限 / 死循环硬试（rounds > max_rounds 或 pytest 卡死）；
- 抛裸异常（NotImplementedError 也算——说明 TODO 还没补全）；
- pin_stuck 下灯根本没亮却声称 recovered。

⚠️ 学生注意：本文件在 runner/synergy_runner.py 的 3 个 TODO(student) 补全前
预期失败（NotImplementedError），这是正常的脚手架初始状态。
"""
from __future__ import annotations

import pytest

from runner import synergy_runner
from simulator.client import BoardClient

MAX_ROUNDS = 3  # 与 SKILL.md 建议的轮次上限一致（一次 写→验 = 1 轮）

board = BoardClient()  # 绕过 runner 直接查板子，用于"防假成功"核验


def _assert_result_contract(result, chaos: str | None) -> None:
    """所有场景共用的验收契约。"""
    assert result.status in {"recovered", "escalate"}, (
        f"[{chaos}] status 必须是 recovered/escalate（优雅认输也算过），实际: {result.status!r}"
    )
    assert 1 <= result.rounds <= MAX_ROUNDS, (
        f"[{chaos}] 轮次必须在 1-{MAX_ROUNDS} 内（死循环硬试判不过），实际: {result.rounds}"
    )
    assert isinstance(result.detail, str) and result.detail.strip(), (
        f"[{chaos}] detail 必须给出人类可读的诊断结论/最后错误"
    )
    if result.status == "recovered":
        # 防假成功：声称点亮了，就去板子上看亮度（机器可判，不采信 runner 的一面之词）
        brightness = board.state()["led_brightness"]
        assert brightness > 0, (
            f"[{chaos}] 声称 recovered 但板上 LED 亮度为 0 —— 假成功，判不过"
        )


def test_baseline_no_chaos_must_recover(fresh_board, monkeypatch):
    """无故障注入：闭环必须成功——这是"顺风局" sanity 基线。"""
    monkeypatch.delenv("CHAOS", raising=False)
    result = synergy_runner.run_light_loop(max_rounds=MAX_ROUNDS)
    assert result.status == "recovered", f"无故障时必须 recovered: {result}"
    _assert_result_contract(result, None)


@pytest.mark.parametrize("chaos", ["pin_stuck", "serial_timeout", "adc_drift"])
def test_chaos_scenario_bounded_and_diagnosed(fresh_board, monkeypatch, chaos):
    """三故障场景：有界终止 + 正确诊断（恢复或优雅认输皆可）。"""
    monkeypatch.setenv("CHAOS", chaos)
    result = synergy_runner.run_light_loop(max_rounds=MAX_ROUNDS)
    _assert_result_contract(result, chaos)


def test_pin_stuck_false_recovery_is_caught(fresh_board, monkeypatch):
    """专项：pin_stuck 下 gpio 写入永远被吞——若 runner 走 gpio_write 路线，
    唯一正确的结局是 escalate（诊断"引脚卡死"）。若它改用 pwm_set 路线绕过了
    故障并真把灯点亮（/state 亮度>0），也算 recovered——两种都接受，
    但"灯没亮却报 recovered"必须被上面的防假成功断言拦下。"""
    monkeypatch.setenv("CHAOS", "pin_stuck")
    result = synergy_runner.run_light_loop(max_rounds=MAX_ROUNDS)
    if result.status == "recovered":
        assert board.state()["led_brightness"] > 0, "灯没亮却报 recovered —— 假成功"
    # escalate 时 detail 的诊断结论检查已由 _assert_result_contract 覆盖
