"""混沌开关自检：先确认"故障"本身的行为符合定义，再谈用它验收学生作品。

本文件是脚手架质量测试（发放时即应全绿），不属于学生任务。
三种模式的行为定义（与 README / SKILL.md 一致）：
- pin_stuck:      gpio_write 返回成功，但读回永远是旧值；
- serial_timeout: 每个接口随机（35%）超时，返回 HTTP 504；
- adc_drift:      ADC 读数整体漂移 +300（LED 物理耦合仍生效）。
"""
from __future__ import annotations

from simulator.client import BoardClient, BoardError

client = BoardClient()  # 地址来自 conftest 设置的 SIMULATOR_URL


class TestPinStuck:
    def test_write_succeeds_but_readback_stale(self, monkeypatch, fresh_board):
        monkeypatch.setenv("CHAOS", "pin_stuck")
        resp = client.gpio_write(4, 1)
        assert resp["ok"] is True, "pin_stuck 下写操作必须假装成功"
        assert client.gpio_read(4)["level"] == 0, "读回必须永远是旧值"

    def test_reset_then_write_still_stuck(self, monkeypatch, fresh_board):
        """复位不能治好卡死的引脚（否则诊断分支太容易蒙混过关）。"""
        monkeypatch.setenv("CHAOS", "pin_stuck")
        client.reset()
        client.gpio_write(4, 1)
        assert client.gpio_read(4)["level"] == 0

    def test_state_reports_chaos_mode(self, monkeypatch, fresh_board):
        monkeypatch.setenv("CHAOS", "pin_stuck")
        assert client.state()["chaos"] == "pin_stuck"


class TestSerialTimeout:
    def test_random_504_and_partial_success(self, monkeypatch, fresh_board):
        """60 次请求应既有 504 又有成功——纯随机的瞬时故障，重试有意义。"""
        monkeypatch.setenv("CHAOS", "serial_timeout")
        errors = oks = 0
        for _ in range(60):
            try:
                client.gpio_read(2)
                oks += 1
            except BoardError as e:
                assert "504" in str(e), f"应返回 504，实际: {e}"
                errors += 1
        assert errors > 0, "60 次请求一次都没超时——serial_timeout 未生效？"
        assert oks > 0, "60 次请求全部超时——概率配置异常（应为 35% 左右）？"


class TestAdcDrift:
    def test_dark_baseline_shifted_by_300(self, monkeypatch, fresh_board):
        monkeypatch.setenv("CHAOS", "adc_drift")
        raw = client.adc_read(34)["raw"]
        # 无漂移时 LED 全灭读数 ≈ 800±40；漂移后 ≈ 1100±40
        assert 1000 <= raw <= 1200, f"暗态读数应整体 +300，实际 raw={raw}"

    def test_led_coupling_still_works(self, monkeypatch, fresh_board):
        """漂移是整体偏移，LED 越亮读数越高的物理耦合仍然生效。"""
        monkeypatch.setenv("CHAOS", "adc_drift")
        dark = client.adc_read(34)["raw"]
        client.gpio_write(2, 1)
        bright = client.adc_read(34)["raw"]
        assert bright - dark > 1500

    def test_drift_breaks_absolute_range_check(self, monkeypatch, fresh_board):
        """漂移必须能击穿 skill 里的绝对区间判定（LED 满亮期望 2900-3100）。"""
        monkeypatch.setenv("CHAOS", "adc_drift")
        client.gpio_write(2, 1)
        raw = client.adc_read(34)["raw"]
        assert raw > 3100, f"漂移后满亮读数应超出 3100，实际 raw={raw}"


class TestNoChaosBaseline:
    def test_normal_board_behaves(self, fresh_board):
        """不注入时一切正常（sanity）。"""
        client.gpio_write(2, 1)
        assert client.gpio_read(2)["level"] == 1
        raw = client.adc_read(34)["raw"]
        assert 2900 <= raw <= 3100
