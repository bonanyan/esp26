"""脚手架完整性自检（发放时即应全绿；学生补全 skill 后也必须保持全绿）。

检查两件事：
1. skills/firmware-synergy/SKILL.md 结构完整：frontmatter、五个工作流小节、负面清单；
2. references/pins.md 存在且含关键引脚约定。

注意：不断言 TODO(student) 的数量——学生补全空位后标记会消失，本测试仍应通过。
TODO 结构是否完好由教师端验收（见 teacher/verification-log.md 的 grep 记录）。
"""
from __future__ import annotations

from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parents[1] / "skills" / "firmware-synergy"
SKILL_MD = SKILL_DIR / "SKILL.md"
PINS_MD = SKILL_DIR / "references" / "pins.md"


def test_skill_frontmatter():
    text = SKILL_MD.read_text(encoding="utf-8")
    assert text.startswith("---\n"), "SKILL.md 必须以 frontmatter 开头"
    front = text.split("---", 2)[1]
    assert "name: firmware-synergy" in front
    assert "description:" in front
    # description 决定触发：必须包含使用场景与工具名等触发词
    for keyword in ("固件", "gpio_write", "adc_read", "触发词"):
        assert keyword in front, f"description 缺少触发关键词: {keyword}"


def test_skill_workflow_sections():
    text = SKILL_MD.read_text(encoding="utf-8")
    for section in ("## 1. 写", "## 2. 查", "## 3. 验", "## 4. 故障诊断分支", "## 5. 停止条件与升级"):
        assert section in text, f"缺少工作流小节: {section}"


def test_skill_negative_list():
    text = SKILL_MD.read_text(encoding="utf-8")
    assert "# 禁止事项" in text
    assert "firmware_flash" in text  # 危险操作双重护栏必须提及


def test_pins_reference_exists():
    text = PINS_MD.read_text(encoding="utf-8")
    assert "GPIO2" in text and "34" in text
