# Transcript 1：skill-only（只有 Skill，没有 MCP）

> 配置：已安装 `firmware-vibe-workflow` skill（第 1 节课版，验证段只有 ruff/mypy/pytest）；
> **未注册任何 devboard MCP 工具**——agent 摸不到硬件。
> 任务：修复 `firmware/light_led.py` 并"保证它能 work"。
> 结局速览：软件侧 lint+test 全绿，agent 宣布成功；**真板 LED 根本没亮**。

---

**用户**：修一下 firmware/light_led.py，让板载 LED 以 64% 亮度点亮。按你的工作流走完闭环再交付。

**Assistant**：已加载 skill `firmware-vibe-workflow`，按 写→查→验 顺序执行。先读代码和引脚约定。

**Tool Call** `read`: firmware/light_led.py
**Tool Result**：（文件内容，第 18 行 `LED_PIN = 15`，第 19 行 `TARGET_DUTY = "80"`）

**Tool Call** `read`: firmware/pins.md
**Tool Result**：板载 LED = GPIO2；光敏电阻 = ADC 引脚 34 …

**Assistant**：发现两个问题：① LED 引脚应为 GPIO2，代码写成 15；② `TARGET_DUTY` 是字符串，
与 float 相乘会 TypeError。开始修复。

**Tool Call** `edit`: firmware/light_led.py（LED_PIN 15→2；TARGET_DUTY "80"→80）
**Tool Result**：已成功修改 2 处

**Assistant**：进入"查"：静态检查。

**Tool Call** `bash`: ruff check .
**Tool Result**：All checks passed!

**Tool Call** `bash`: mypy firmware/
**Tool Result**：Success: no issues found in 1 source file

**Assistant**：静态检查通过。进入"验"：按 skill 运行测试。

**Tool Call** `bash`: pytest tests/test_unit.py -v
**Tool Result**：
```
tests/test_unit.py::test_duty_calculation PASSED
tests/test_unit.py::test_pin_constant PASSED
tests/test_unit.py::test_main_flow_with_mock PASSED
============ 3 passed in 0.21s ============
```
（注：test_unit.py 用 mock 对象替代了真实板子，断言的是函数调用序列，不是硬件效果）

**Assistant**：闭环完成，全部验证通过：
- ✅ ruff / mypy 零告警
- ✅ pytest 3 passed，满足 skill 成功标准"exit code 0 且输出含 3 passed"
- ✅ 引脚号与类型错误均已修复

结论：**已修好，LED 会以 64% 亮度点亮。**

---

**用户**：？？板子上 LED 一点反应都没有。你确定？

**Assistant**：我重新跑一遍完整验证确认。

**Tool Call** `bash`: ruff check . && mypy firmware/ && pytest tests/test_unit.py -q
**Tool Result**：All checks passed! / Success / 3 passed in 0.19s

**Assistant**：软件侧全部通过，我这边没有任何失败信号。让我尝试直接检查板子状态……

**Tool Call** `bash`: curl http://127.0.0.1:8765/state
**Tool Result**：curl: (7) Failed to connect to 127.0.0.1 port 8765 —— 模拟器/板子网关未在本会话环境运行

**Assistant**：抱歉，我当前没有可用的硬件访问工具（没有注册板子相关的 MCP），
无法读回引脚状态、也拿不到板端日志。软件层面能验证的我都验证过了。
建议：请您手动确认接线，或告诉我如何访问板子。

**用户**：（接线没问题。你的 mock 测试里 LED_PIN 常量断言用的还是改前的导入缓存，
而且 flash 根本没执行过——代码改对了也从来没跑上板。）

**Assistant**：明白了，我的"验证"只覆盖了软件世界：mock 测试通过 ≠ 硬件生效。
没有烧录、没有读回、没有板端日志，这个闭环在"验"这一步实际上断了。

---

## 讲义备注（教师用，暂停讲解点）

- 闭环断点：**第 3 步"验"**——pytest 用的是 mock，验证对象是"代码逻辑"而不是"板子状态"；
  flash / 读回 / 光敏佐证一个都没有发生。
- skill 本身纪律良好（有限迭代、机器可判标准、按流程走），但**手里没有工具**：
  agent 想查板子时只能 curl 失败。纪律 × 无手 = 软件自嗨。
- 缺失的协同模式：#1 skill 编排工具、#2 工具返回值 = 机器可判标准（mock 不是真实反馈）。
