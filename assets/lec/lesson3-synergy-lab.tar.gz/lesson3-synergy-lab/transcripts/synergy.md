# Transcript 3：synergy（Skill × MCP 协同）

> 配置：`firmware-synergy` skill（已补全 3 个空位的版本）+ devboard MCP 全部工具。
> 任务：让板载 LED 以 64% 亮度点亮，并给出机器可判的验证证据。
> 结局速览：1 轮通过——编排工具 + 写后读回比对 + get_logs 佐证，全程零重试。

---

**用户**：按 firmware-synergy 工作流，把板载 LED 调到 64% 亮度，交付时给我验证证据。

**Assistant**：已加载 skill `firmware-synergy`。按流程执行：

**第 1 步（写）**：先查引脚约定，再定验证标准。

**Tool Call** `read`: skills/firmware-synergy/references/pins.md
**Tool Result**：板载 LED = GPIO2（支持 PWM，duty 即亮度%）；光敏 = ADC34；
物理特性：暗态基础读数 ≈800，LED 满亮 ≈3000，噪声 ±40 …

**Assistant**：由物理特性推导本次的机器可判成功标准：
duty=64% → 期望 raw ≈ 800 + 2200×0.64 = 2208，留噪声与量化余量，
**判定区间 raw ∈ [2100, 2320]**。区间外的任何读数都不算成功。

先把固件烧上板（skill 双重护栏：烧录是危险操作，需先确认）：
`firmware_flash` 将烧录 firmware/light_led.py（内容：64% 亮度点灯 + 读回自检），
该操作会覆盖板上现有固件且不可逆——**请确认是否烧录？**

**用户**：确认，烧。

**Tool Call** `mcp: firmware_flash` {"firmware_path": "firmware/light_led.py", "confirm": true}
**Tool Result**：OK: 已烧录固件 light_led.py（1152 字节）。建议随后用 get_logs 确认烧录事件

**第 2 步（查）**：静态检查。

**Tool Call** `bash`: ruff check .
**Tool Result**：All checks passed!

**第 3 步（验·硬件在环）**：动作 → 读回比对 → 日志佐证，一个都不少。

**Tool Call** `mcp: pwm_set` {"pin": 2, "duty": 64}
**Tool Result**：OK: GPIO2 PWM 占空比已设为 64%

**Assistant**：写入返回 OK。按 skill：**OK 只代表写请求被接受，不代表灯亮了**，
读回比对（TODO① 空位的实现）：用光敏读数做物理验证——灯真亮了，光敏必然升高。

**Tool Call** `mcp: adc_read` {"pin": 34}
**Tool Result**：OK: ADC34 原始值 raw = 2214 (0-4095, 12-bit), 电压 = 1.786 V (0-3.3V)

**Assistant**：raw = 2214 ∈ [2100, 2320] ✅（第一次采样即命中，无需重采）。
再取一次确认不是噪声巧合：

**Tool Call** `mcp: adc_read` {"pin": 34}
**Tool Result**：OK: ADC34 原始值 raw = 2201 (0-4095, 12-bit), 电压 = 1.775 V (0-3.3V)

**Assistant**：两次采样 2214 / 2201，均在判定区间内且相差 <±40 噪声带 ✅。
最后查板端日志，确认这些操作真实发生在板子上（防"写进虚空"）：

**Tool Call** `mcp: get_logs` {"limit": 8}
**Tool Result**：
```
OK: 最近 8 条日志（旧→新）:
[21:03:11] board reset: GPIO/PWM/固件已清空
[21:03:11] firmware_flash: 已烧录 light_led.py（1152 字节）
[21:03:15] pwm_set: GPIO2 duty=64%
```

**Assistant**：日志与我的操作序列一一对应，无被拒绝请求、无异常事件 ✅。

**交付结论（1 轮通过，零重试）**：

| 验证项 | 判定标准（机器可判） | 实测 | 结果 |
|---|---|---|---|
| 写入 | pwm_set 返回以 OK 开头 | OK: GPIO2 duty=64% | ✅ |
| 物理读回 | adc_read raw ∈ [2100, 2320] | 2214 / 2201 | ✅ |
| 板端日志 | get_logs 含本次 flash + pwm_set 事件 | 均出现 | ✅ |
| 静态检查 | ruff exit 0 | All checks passed | ✅ |

LED 已稳定在 64% 亮度。诊断分支与停止条件本轮未触发（无故障）；
若读回越界，我会按 skill 第 4/5 节：超时→重试≤2 次，不一致→reset 后重试 1 次，
仍失败→停止并向您报告诊断结论，绝不无限重试。

**用户**：这就是我想要的"保证它能 work"。

---

## 讲义备注（教师用，暂停讲解点）

- 闭环完整：**写（编排工具）→ 查（静态）→ 验（读回比对 + 物理佐证 + 日志佐证）**，
  每一环的成功标准都是机器可判的（OK 前缀 / 数值区间 / 日志匹配）。
- 关键差异点（对照前两份 transcript）：
  1. "OK" 不被当作成功——只是写请求被接受，成功 = 读回命中**预先推导的区间**；
  2. 判定区间来自 pins.md 物理特性（渐进披露），不是拍脑袋；
  3. flash 前有用户确认（skill 层护栏 + MCP 层 confirm 参数校验 = 双重护栏）；
  4. 诊断分支与停止条件写在 skill 里，本轮没用上，但"没用上"恰恰是因为前面每一步都有据可查。
- 体现的协同模式：#1 编排、#2 机器可判标准、#3 双重护栏、#4 渐进披露、#5 升级路径（备而未发）。
